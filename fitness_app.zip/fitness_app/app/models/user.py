from datetime import datetime
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from app import db, login_manager

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    email = db.Column(db.String(120), unique=True, nullable=True)
    password_hash = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    profile = db.relationship('UserProfile', backref='user', uselist=False, cascade='all, delete-orphan')
    preferences = db.relationship('UserPreferences', backref='user', uselist=False, cascade='all, delete-orphan')
    recipes = db.relationship('Recipe', backref='user', lazy=True, cascade='all, delete-orphan')
    workout_logs = db.relationship('UserWorkoutLog', backref='user', lazy=True, cascade='all, delete-orphan')
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def __repr__(self):
        return f'<User {self.username}>'


class UserProfile(db.Model):
    __tablename__ = 'user_profiles'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    age = db.Column(db.Integer, nullable=True)
    nickname = db.Column(db.String(80), nullable=True)
    gender = db.Column(db.String(10), nullable=True)
    height_cm = db.Column(db.Integer, nullable=True)
    starting_weight_kg = db.Column(db.Float, nullable=True)
    current_weight_kg = db.Column(db.Float, nullable=True)
    goal = db.Column(db.String(20), nullable=True)
    
    target_weight_kg = db.Column(db.Float, nullable=True)
    weekly_weight_goal = db.Column(db.Float, nullable=True)
    
    sleep_hours = db.Column(db.Float, nullable=True)
    sleep_quality = db.Column(db.String(20), nullable=True)
    wake_time = db.Column(db.String(10), nullable=True)
    bed_time = db.Column(db.String(10), nullable=True)
    
    job_activity_level = db.Column(db.String(50), nullable=True)
    work_start_time = db.Column(db.String(10), nullable=True)
    work_end_time = db.Column(db.String(10), nullable=True)
    work_days_per_week = db.Column(db.String(100), nullable=True)
    workout_time_preference = db.Column(db.String(20), nullable=True)
    
    training_days = db.Column(db.String(200), nullable=True)
    
    view_preference = db.Column(db.String(10), default='weekly')
    
    bmr = db.Column(db.Integer, nullable=True)
    tdee = db.Column(db.Integer, nullable=True)
    target_calories = db.Column(db.Integer, nullable=True)
    target_protein_g = db.Column(db.Integer, nullable=True)
    target_carbs_g = db.Column(db.Integer, nullable=True)
    target_fat_g = db.Column(db.Integer, nullable=True)
    target_water_ml = db.Column(db.Integer, nullable=True)
    
    daily_steps_goal = db.Column(db.Integer, nullable=True)
    current_daily_steps = db.Column(db.Integer, nullable=True)
    
    program_type = db.Column(db.String(20), nullable=True)
    program_target_kg = db.Column(db.Float, nullable=True)
    program_start_date = db.Column(db.Date, nullable=True)
    program_start_weight = db.Column(db.Float, nullable=True)
    completed_weeks = db.Column(db.Integer, default=0)
    program_weeks = db.Column(db.Integer, nullable=True)
    
    calorie_adjustment = db.Column(db.Integer, default=0)
    steps_adjustment = db.Column(db.Integer, default=0)
    
    current_running_distance_km = db.Column(db.Float, nullable=True)
    current_running_pace_min = db.Column(db.Float, nullable=True)
    current_cycling_distance_km = db.Column(db.Float, nullable=True)
    current_swimming_distance_m = db.Column(db.Integer, nullable=True)
    current_walking_distance_km = db.Column(db.Float, nullable=True)
    
    baseline_running_distance_km = db.Column(db.Float, nullable=True)
    baseline_running_pace_min = db.Column(db.Float, nullable=True)
    baseline_cycling_distance_km = db.Column(db.Float, nullable=True)
    baseline_swimming_distance_m = db.Column(db.Integer, nullable=True)
    baseline_walking_distance_km = db.Column(db.Float, nullable=True)
    
    current_bodyweight_reps = db.Column(db.Text, nullable=True)
    baseline_bodyweight_reps = db.Column(db.Text, nullable=True)
    
    step2_completed = db.Column(db.Boolean, default=False)
    step3_completed = db.Column(db.Boolean, default=False)
    has_completed_first_checkin = db.Column(db.Boolean, default=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def calculate_bmr(self):
        if not all([self.current_weight_kg, self.height_cm, self.age, self.gender]):
            return None
        
        if self.gender == 'male':
            bmr = 10 * self.current_weight_kg + 6.25 * self.height_cm - 5 * self.age + 5
        else:
            bmr = 10 * self.current_weight_kg + 6.25 * self.height_cm - 5 * self.age - 161
        
        return int(bmr)
    
    def calculate_tdee(self, activity_multiplier=1.2):
        bmr = self.calculate_bmr()
        if not bmr:
            return None
        return int(bmr * activity_multiplier)
    
    def calculate_targets(self):
        self.bmr = self.calculate_bmr()
        
        activity_map = {
            'ülő': 1.2,
            'ulo': 1.2,
            'könnyű': 1.375,
            'konnyu': 1.375,
            'közepes': 1.55,
            'kozepes': 1.55,
            'nehéz': 1.725,
            'nehez': 1.725,
            'nagyon nehéz': 1.9,
            'nagyon nehez': 1.9
        }
        
        multiplier = 1.2
        if self.job_activity_level:
            multiplier = activity_map.get(self.job_activity_level.lower(), 1.2)
        
        self.tdee = self.calculate_tdee(multiplier)
        
        if not self.tdee:
            return
        
        if self.goal == 'fogyás':
            self.target_calories = self.tdee - 500
        elif self.goal == 'izomépítés':
            self.target_calories = self.tdee + 300
        else:
            self.target_calories = self.tdee
        
        weight = self.current_weight_kg or 70
        if self.goal == 'izomépítés':
            self.target_protein_g = int(weight * 2.0)
        else:
            self.target_protein_g = int(weight * 1.6)
        
        self.target_fat_g = int(self.target_calories * 0.25 / 9)
        remaining_cals = self.target_calories - (self.target_protein_g * 4) - (self.target_fat_g * 9)
        self.target_carbs_g = int(remaining_cals / 4)
        
        self.target_water_ml = int(weight * 33)
        
        if not self.daily_steps_goal or self.daily_steps_goal == 0:
            if self.goal == 'fogyás':
                self.daily_steps_goal = 5000
            elif self.goal == 'karban tartás':
                self.daily_steps_goal = 5000
            else:
                self.daily_steps_goal = 5000
        
        pass
    
    def __repr__(self):
        return f'<UserProfile user_id={self.user_id}>'


class UserPreferences(db.Model):
    __tablename__ = 'user_preferences'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    selected_workout_types = db.Column(db.String(200), nullable=True)
    experience_level = db.Column(db.String(20), nullable=True)
    weekly_workout_count = db.Column(db.Integer, nullable=True)
    daily_meals_count = db.Column(db.Integer, nullable=True)
    
    walking_avg_daily_km = db.Column(db.Float, nullable=True)
    walking_avg_daily_min = db.Column(db.Integer, nullable=True)
    
    running_pace_min = db.Column(db.Integer, nullable=True)
    running_pace_sec = db.Column(db.Integer, nullable=True)
    running_avg_distance_km = db.Column(db.Float, nullable=True)
    running_frequency = db.Column(db.Integer, nullable=True)
    
    bodyweight_equipment = db.Column(db.String(100), nullable=True)
    
    swimming_avg_distance_m = db.Column(db.Integer, nullable=True)
    swimming_avg_time_min = db.Column(db.Integer, nullable=True)
    
    cycling_avg_distance_km = db.Column(db.Float, nullable=True)
    cycling_avg_time_min = db.Column(db.Integer, nullable=True)
    cycling_type = db.Column(db.String(50), nullable=True)
    
    day_workout_mapping = db.Column(db.Text, nullable=True)
    
    step4_completed = db.Column(db.Boolean, default=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<UserPreferences user_id={self.user_id}>'


class Recipe(db.Model):
    __tablename__ = 'recipes'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    
    api_id = db.Column(db.Integer, nullable=True)
    name = db.Column(db.String(200), nullable=False)
    category = db.Column(db.String(50), nullable=True)
    image_url = db.Column(db.String(500))
    source_url = db.Column(db.String(500), nullable=True)
    
    calories = db.Column(db.Float)
    protein_g = db.Column(db.Float)
    carbs_g = db.Column(db.Float)
    fat_g = db.Column(db.Float)
    
    ingredients = db.Column(db.Text)
    instructions = db.Column(db.Text)
    servings = db.Column(db.Integer, default=1)
    ready_in_minutes = db.Column(db.Integer)
    
    is_favorite = db.Column(db.Boolean, default=False)
    is_manual = db.Column(db.Boolean, default=False)
    is_seed = db.Column(db.Boolean, default=False)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<Recipe {self.name}>'



class WorkoutPlan(db.Model):  #nem hasznaljuk egyelore
    __tablename__ = 'workout_plans'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=True)
    
    goal = db.Column(db.String(50), nullable=False)
    experience = db.Column(db.String(50), nullable=False)
    location = db.Column(db.String(50), nullable=False)
    weekly_frequency = db.Column(db.Integer, nullable=False)
    
    duration_weeks = db.Column(db.Integer, default=12)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    workout_days = db.relationship('WorkoutDay', backref='plan', lazy=True, cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<WorkoutPlan {self.name}>'


class WorkoutDay(db.Model):  #nem hasznaljuk egyelore
    __tablename__ = 'workout_days'
    
    id = db.Column(db.Integer, primary_key=True)
    workout_plan_id = db.Column(db.Integer, db.ForeignKey('workout_plans.id'), nullable=False)
    
    day_number = db.Column(db.Integer, nullable=False)
    name = db.Column(db.String(200), nullable=False)
    focus = db.Column(db.String(100), nullable=True)
    description = db.Column(db.Text, nullable=True)
    
    exercises = db.relationship('WorkoutDayExercise', backref='workout_day', lazy=True, cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<WorkoutDay {self.name}>'


class Exercise(db.Model):  #nem hasznaljuk egyelore
    __tablename__ = 'exercises'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    english_name = db.Column(db.String(200), nullable=True)
    
    muscle_group = db.Column(db.String(100), nullable=False)
    equipment = db.Column(db.String(100), nullable=False)
    difficulty = db.Column(db.String(50), nullable=False)
    
    description = db.Column(db.Text, nullable=True)
    instructions = db.Column(db.Text, nullable=True)
    tips = db.Column(db.Text, nullable=True)
    
    image_url = db.Column(db.String(500), nullable=True)
    video_url = db.Column(db.String(500), nullable=True)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<Exercise {self.name}>'


class WorkoutDayExercise(db.Model):  #nem hasznaljuk egyelore
    __tablename__ = 'workout_day_exercises'
    
    id = db.Column(db.Integer, primary_key=True)
    workout_day_id = db.Column(db.Integer, db.ForeignKey('workout_days.id'), nullable=False)
    exercise_id = db.Column(db.Integer, db.ForeignKey('exercises.id'), nullable=False)
    
    order = db.Column(db.Integer, nullable=False)
    sets = db.Column(db.Integer, nullable=False)
    reps = db.Column(db.String(50), nullable=False)
    rest_seconds = db.Column(db.Integer, default=90)
    notes = db.Column(db.Text, nullable=True)
    
    exercise = db.relationship('Exercise', backref='workout_assignments')
    
    def __repr__(self):
        return f'<WorkoutDayExercise {self.exercise_id}>'


class UserWorkoutLog(db.Model):  #nem hasznaljuk egyelore
    __tablename__ = 'user_workout_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    workout_day_id = db.Column(db.Integer, db.ForeignKey('workout_days.id'), nullable=False)
    
    date = db.Column(db.DateTime, default=datetime.utcnow)
    completed = db.Column(db.Boolean, default=False)
    duration_minutes = db.Column(db.Integer, nullable=True)
    notes = db.Column(db.Text, nullable=True)
    
    workout_day = db.relationship('WorkoutDay', backref='user_logs')
    exercise_logs = db.relationship('UserExerciseLog', backref='workout_log', lazy=True, cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<UserWorkoutLog {self.user_id} - {self.date}>'


class UserExerciseLog(db.Model):  #nem hasznaljuk egyelore
    __tablename__ = 'user_exercise_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    user_workout_log_id = db.Column(db.Integer, db.ForeignKey('user_workout_logs.id'), nullable=False)
    exercise_id = db.Column(db.Integer, db.ForeignKey('exercises.id'), nullable=False)
    
    set_number = db.Column(db.Integer, nullable=False)
    reps_completed = db.Column(db.Integer, nullable=True)
    weight_kg = db.Column(db.Float, nullable=True)
    notes = db.Column(db.Text, nullable=True)
    
    exercise = db.relationship('Exercise', backref='user_logs')
    
    def __repr__(self):
        return f'<UserExerciseLog {self.exercise_id} - Set {self.set_number}>'


class DailyLog(db.Model): 
    __tablename__ = 'daily_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    date = db.Column(db.Date, nullable=False)
    
    steps_completed = db.Column(db.Integer, nullable=True)
    steps_goal = db.Column(db.Integer, nullable=True)
    walking_minutes = db.Column(db.Integer, nullable=True)
    
    calories_consumed = db.Column(db.Integer, nullable=True)
    calories_goal = db.Column(db.Integer, nullable=True)
    water_ml = db.Column(db.Integer, nullable=True)
    water_goal = db.Column(db.Integer, nullable=True)
    meals_count = db.Column(db.Integer, nullable=True)
    
    protein_g = db.Column(db.Integer, nullable=True)
    carbs_g = db.Column(db.Integer, nullable=True)
    fat_g = db.Column(db.Integer, nullable=True)
    protein_goal = db.Column(db.Integer, nullable=True)
    carbs_goal = db.Column(db.Integer, nullable=True)
    fat_goal = db.Column(db.Integer, nullable=True)
    
    weight_kg = db.Column(db.Float, nullable=True)
    sleep_hours = db.Column(db.Float, nullable=True)
    
    exercise_type = db.Column(db.String(20), nullable=True)
    exercise_distance_km = db.Column(db.Float, nullable=True)
    exercise_distance_m = db.Column(db.Integer, nullable=True)
    exercise_time_minutes = db.Column(db.Integer, nullable=True)
    average_pace_min_km = db.Column(db.Float, nullable=True)
    average_speed_kmh = db.Column(db.Float, nullable=True)
    average_pace_min_100m = db.Column(db.Float, nullable=True)
    exercise_intensity = db.Column(db.String(20), nullable=True)
    terrain_type = db.Column(db.String(20), nullable=True)
    
    bodyweight_exercises_count = db.Column(db.Integer, nullable=True)
    bodyweight_rounds = db.Column(db.Integer, nullable=True)
    bodyweight_performance = db.Column(db.Text, nullable=True)
    
    target_walking_distance_km = db.Column(db.Float, nullable=True)
    target_running_distance_km = db.Column(db.Float, nullable=True)
    target_cycling_distance_km = db.Column(db.Float, nullable=True)
    target_swimming_distance_m = db.Column(db.Integer, nullable=True)
    target_bodyweight_reps = db.Column(db.Text, nullable=True)
    
    completed = db.Column(db.Boolean, default=False)
    notes = db.Column(db.Text, nullable=True)
    
    is_work_day = db.Column(db.Boolean, nullable=True)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    __table_args__ = (db.UniqueConstraint('user_id', 'date', name='unique_user_date'),)
    
    def __repr__(self):
        return f'<DailyLog {self.user_id} - {self.date}>'


class WeeklyResult(db.Model):
    __tablename__ = 'weekly_results'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    week_start = db.Column(db.Date, nullable=False)
    week_end = db.Column(db.Date, nullable=False)
    week_number = db.Column(db.Integer, nullable=True)
    program_type = db.Column(db.String(20), nullable=True)
    
    total_steps = db.Column(db.Integer, nullable=True)
    total_km = db.Column(db.Float, nullable=True)
    total_calories_burned = db.Column(db.Integer, nullable=True)
    total_walking_minutes = db.Column(db.Integer, nullable=True)
    total_water_ml = db.Column(db.Integer, nullable=True)
    
    steps_goal = db.Column(db.Integer, nullable=True)
    steps_achievement = db.Column(db.Integer, nullable=True)
    
    start_weight = db.Column(db.Float, nullable=True)
    end_weight = db.Column(db.Float, nullable=True)
    weight_change = db.Column(db.Float, nullable=True)
    
    avg_sleep = db.Column(db.Float, nullable=True)
    
    daily_steps_json = db.Column(db.Text, nullable=True)
    daily_labels_json = db.Column(db.Text, nullable=True)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<WeeklyResult {self.user_id} - {self.week_start}>'
