from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, IntegerField, SelectField, FloatField, SelectMultipleField
from wtforms.validators import DataRequired, Length, EqualTo, ValidationError, Email, NumberRange
from app.models.user import User


class EmptyForm(FlaskForm):
    pass

class RegistrationForm(FlaskForm):
    username = StringField('Felhasználónév', 
                          validators=[
                              DataRequired(message='A felhasználónév megadása kötelező!'), 
                              Length(min=3, max=80, message='3-80 karakter között!')
                          ])
    
    email = StringField('Email cím', 
                       validators=[
                           DataRequired(message='Az email cím megadása kötelező!'),
                           Email(message='Érvényes email címet adj meg!')
                       ])
    
    password = PasswordField('Jelszó', 
                            validators=[
                                DataRequired(message='A jelszó megadása kötelező!'),
                                Length(min=6, message='Legalább 6 karakter!')
                            ])
    
    password_confirm = PasswordField('Jelszó megerősítése',
                                    validators=[
                                        DataRequired(message='A jelszó megerősítése kötelező!'),
                                        EqualTo('password', message='A jelszavak nem egyeznek!')
                                    ])
    
    def validate_username(self, username):
        user = User.query.filter_by(username=username.data).first()
        if user:
            raise ValidationError('Ez a felhasználónév foglalt!')
    
    def validate_email(self, email):
        user = User.query.filter_by(email=email.data).first()
        if user:
            raise ValidationError('Ez az email cím már regisztrálva van!')


class ProfileStep2Form(FlaskForm):
    age = IntegerField('Életkor', 
                      validators=[
                          DataRequired(message='Az életkor megadása kötelező!'),
                          NumberRange(min=14, max=100, message='14-100 között!')
                      ])
    
    nickname = StringField('Becenév', 
                          validators=[
                              DataRequired(message='A becenév megadása kötelező!'),
                              Length(min=2, max=30, message='2-30 karakter között!')
                          ])
    
    gender = SelectField('Nem',
                        choices=[
                            ('', 'Válassz...'),
                            ('male', 'Férfi'),
                            ('female', 'Nő')
                        ],
                        validators=[DataRequired(message='A nem megadása kötelező!')])
    
    height_cm = IntegerField('Magasság (cm)',
                            validators=[
                                DataRequired(message='A magasság megadása kötelező!'),
                                NumberRange(min=120, max=250, message='120-250 cm között!')
                            ])
    
    starting_weight_kg = FloatField('Jelenlegi testsúly (kg)',
                                   validators=[
                                       DataRequired(message='A testsúly megadása kötelező!'),
                                       NumberRange(min=30, max=300, message='30-300 kg között!')
                                   ])
    
    goal = SelectField('Célod',
                      choices=[
                          ('', 'Válassz...'),
                          ('fogyás', 'Fogyás'),
                          ('karban tartás', 'Testsúly fenntartás'),
                          ('izomépítés', 'Tömegnövelés / Izomépítés')
                      ],
                      validators=[DataRequired(message='A cél megadása kötelező!')])


class ProfileStep3Form(FlaskForm):
    job_activity_level = SelectField('Munkavégzés jellege',
                                    choices=[
                                        ('', 'Válassz...'),
                                        ('sedentary', 'Ülőmunka (irodai munka)'),
                                        ('light', 'Könnyű aktivitás (tanár, eladó)'),
                                        ('moderate', 'Közepes aktivitás (ápoló, pincér)'),
                                        ('heavy', 'Fizikai munka (raktáros, kézműves)')
                                    ],
                                    validators=[DataRequired(message='Válassz egyet!')])
    
    work_start_time = SelectField('Munkakezdés',
                                 choices=[
                                     ('', 'Válassz...'),
                                     ('05:00', '5:00'),
                                     ('06:00', '6:00'),
                                     ('07:00', '7:00'),
                                     ('08:00', '8:00'),
                                     ('09:00', '9:00'),
                                     ('10:00', '10:00'),
                                     ('11:00', '11:00'),
                                     ('12:00', '12:00'),
                                     ('14:00', '14:00'),
                                     ('16:00', '16:00'),
                                     ('18:00', '18:00'),
                                     ('20:00', '20:00'),
                                     ('22:00', '22:00 (éjszakai)')
                                 ],
                                 validators=[DataRequired(message='Add meg a munkakezdés idejét!')])
    
    work_end_time = SelectField('Munkavégzés vége',
                               choices=[
                                   ('', 'Válassz...'),
                                   ('12:00', '12:00'),
                                   ('13:00', '13:00'),
                                   ('14:00', '14:00'),
                                   ('15:00', '15:00'),
                                   ('16:00', '16:00'),
                                   ('17:00', '17:00'),
                                   ('18:00', '18:00'),
                                   ('19:00', '19:00'),
                                   ('20:00', '20:00'),
                                   ('21:00', '21:00'),
                                   ('22:00', '22:00'),
                                   ('00:00', '00:00'),
                                   ('02:00', '02:00'),
                                   ('06:00', '06:00 (éjszakai)')
                               ],
                               validators=[DataRequired(message='Add meg a munkavégzés végét!')])
    
    work_days_per_week = SelectMultipleField('Munkanapok',
                                            choices=[
                                                ('monday', 'Hétfő'),
                                                ('tuesday', 'Kedd'),
                                                ('wednesday', 'Szerda'),
                                                ('thursday', 'Csütörtök'),
                                                ('friday', 'Péntek'),
                                                ('saturday', 'Szombat'),
                                                ('sunday', 'Vasárnap')
                                            ])


class ProfileStep4Form(FlaskForm):
    preferred_exercises = SelectMultipleField('Preferált edzéstípusok',
                                             choices=[
                                                 ('walking', 'Séta'),
                                                 ('weightlifting', 'Súlyzós edzés'),
                                                 ('running', 'Futás'),
                                                 ('bodyweight', 'Saját testsúly'),
                                                 ('yoga', 'Jóga'),
                                                 ('swimming', 'Úszás'),
                                                 ('cycling', 'Kerékpározás')
                                             ])
    
    workout_split = SelectField('Edzésbeosztás',
                               choices=[
                                   ('', 'Válassz...'),
                                   ('push_pull_legs', 'Push/Pull/Legs'),
                                   ('upper_lower', 'Upper/Lower'),
                                   ('full_body', 'Full Body'),
                                   ('bro_split', 'Bro-split')
                               ],
                               default='')
    
    running_pace_km = IntegerField('Futás tempó - Km',
                                  validators=[NumberRange(min=1, max=50, message='1-50 km között!')],
                                  default=None)
    running_pace_min = IntegerField('Futás tempó - Perc',
                                   validators=[NumberRange(min=1, max=300, message='1-300 perc között!')],
                                   default=None)

    swimming_distance = IntegerField('Átlag úszott távolság (méter/alkalom)',
                                    validators=[NumberRange(min=100, max=10000, message='100-10000 méter!')],
                                    default=None)
    swimming_time = IntegerField('Átlag úszási idő (perc/alkalom)',
                                validators=[NumberRange(min=5, max=300, message='5-300 perc!')],
                                default=None)
    
    cycling_distance = IntegerField('Átlag kerékpározott távolság (km/alkalom)',
                                   validators=[NumberRange(min=5, max=200, message='5-200 km!')],
                                   default=None)
    cycling_time = IntegerField('Átlag kerékpározási idő (perc/alkalom)',
                               validators=[NumberRange(min=10, max=600, message='10-600 perc!')],
                               default=None)
    
    weekly_workout_count = IntegerField('Heti edzések száma',
                                       validators=[
                                           DataRequired(message='Add meg a heti edzésszámot!'),
                                           NumberRange(min=0, max=7, message='0-7 között!')
                                       ])


class LoginForm(FlaskForm):
    """Bejelentkezési form"""
    username = StringField('Felhasználónév vagy Email',
                          validators=[DataRequired(message='Add meg a felhasználóneved vagy email címed!')])
    
    password = PasswordField('Jelszó',
                            validators=[DataRequired(message='A jelszó megadása kötelező!')])
