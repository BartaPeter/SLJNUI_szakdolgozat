import requests
import json
from flask import Blueprint, render_template, redirect, url_for, flash, request, current_app
from flask_login import login_required, current_user
from app import db
from app.models.user import Recipe

bp = Blueprint('recipes', __name__, url_prefix='/recipes')


@bp.route('/')
@login_required
def index():
    
    manual_recipes = []
    
    seed_recipe_ids = db.session.query(Recipe.id).filter(Recipe.is_seed == True).all()
    seed_recipe_ids = [r[0] for r in seed_recipe_ids]
    
    seed_recipes = Recipe.query.filter(
        (Recipe.is_seed == True) | 
        ((Recipe.user_id == current_user.id) & 
         ~Recipe.api_id.in_(seed_recipe_ids))
    ).order_by(Recipe.created_at.desc()).all()
    
    user_favorite_copies = Recipe.query.filter(
        Recipe.user_id == current_user.id,
        Recipe.api_id.in_(seed_recipe_ids),
        Recipe.is_favorite == True
    ).all()
    
    favorite_seed_ids = {recipe.api_id for recipe in user_favorite_copies}
    
    query = request.args.get('q', '')
    category = request.args.get('category', '')
    api_search = request.args.get('api_search', '0') == '1'
    api_recipes = []
    
    if category:
        seed_recipes = [r for r in seed_recipes if r.category == category]
    
    if query:
        if api_search:
            api_recipes = search_recipes_api(query)
            seed_recipes = []
            manual_recipes = []
        else:
            search_query = query.lower()
            
            seed_results = [r for r in seed_recipes if search_query in r.name.lower()]
            
            if seed_results:
                seed_recipes = seed_results
                manual_recipes = []
                api_recipes = []
            else:
                seed_recipes = []
                manual_recipes = []
                api_recipes = []
    else:
        api_recipes = []
        manual_recipes = []
    
    return render_template('recipes/index.html', 
                         manual_recipes=manual_recipes,
                         seed_recipes=seed_recipes,
                         api_recipes=api_recipes,
                         favorite_seed_ids=favorite_seed_ids,
                         query=query,
                         category=category,
                         api_search=api_search)


@bp.route('/search')
@login_required
def search():
    query = request.args.get('q', '')
    
    if not query:
        flash('Adj meg egy keresési kulcsszót!', 'warning')
        return redirect(url_for('recipes.index'))
    
    return redirect(url_for('recipes.index', q=query))


@bp.route('/details/<int:recipe_id>')
@login_required
def details(recipe_id):
    import json
    
    seed_recipe = Recipe.query.filter_by(id=recipe_id, is_seed=True).first()
    
    if seed_recipe:
        ingredients_list = []
        if seed_recipe.ingredients:
            try:
                parsed = json.loads(seed_recipe.ingredients) if isinstance(seed_recipe.ingredients, str) else seed_recipe.ingredients
                if isinstance(parsed, list):
                    ingredients_list = parsed
                else:
                    ingredients_list = [str(parsed)]
            except:
                ingredients_list = [seed_recipe.ingredients]
        
        instructions_list = []
        if seed_recipe.instructions:
            try:
                parsed = json.loads(seed_recipe.instructions) if isinstance(seed_recipe.instructions, str) else seed_recipe.instructions
                if isinstance(parsed, list):
                    instructions_list = parsed
                elif isinstance(parsed, str):
                    instructions_list = [parsed]
                else:
                    instructions_list = [str(parsed)]
            except:
                instructions_list = [seed_recipe.instructions]
        
        recipe_data = {
            'id': seed_recipe.id,
            'title': seed_recipe.name,
            'image': seed_recipe.image_url,
            'servings': seed_recipe.servings or 1,
            'readyInMinutes': seed_recipe.ready_in_minutes,
            'nutrition': {
                'calories': int(seed_recipe.calories or 0),
                'protein': round(seed_recipe.protein_g or 0, 1),
                'carbs': round(seed_recipe.carbs_g or 0, 1),
                'fat': round(seed_recipe.fat_g or 0, 1)
            },
            'ingredients': ingredients_list,
            'instructions': instructions_list
        }
        
        return render_template('recipes/details.html', 
                             recipe=recipe_data, 
                             is_favorite=False,
                             is_seed=True)
    
    recipe_data = get_recipe_details_api(recipe_id)
    
    if not recipe_data:
        flash('A recept nem található!', 'danger')
        return redirect(url_for('recipes.index'))
    
    existing = Recipe.query.filter_by(api_id=recipe_id, user_id=current_user.id).first()
    is_favorite = existing.is_favorite if existing else False
    
    return render_template('recipes/details.html', recipe=recipe_data, is_favorite=is_favorite, is_seed=False)


@bp.route('/toggle-favorite/<int:api_recipe_id>', methods=['POST'])
@login_required
def toggle_favorite(api_recipe_id):
    recipe = Recipe.query.filter_by(api_id=api_recipe_id, user_id=current_user.id).first()
    
    if recipe:
        recipe.is_favorite = not recipe.is_favorite
        action = 'hozzáadva' if recipe.is_favorite else 'eltávolítva'
    else:
        recipe_data = get_recipe_details_api(api_recipe_id)
        if not recipe_data:
            flash('A recept nem található!', 'danger')
            return redirect(url_for('recipes.index'))
        
        recipe = Recipe(
            user_id=current_user.id,
            api_id=api_recipe_id,
            name=recipe_data['title'],
            image_url=recipe_data['image'],
            calories=recipe_data['nutrition']['calories'],
            protein_g=recipe_data['nutrition']['protein'],
            carbs_g=recipe_data['nutrition']['carbs'],
            fat_g=recipe_data['nutrition']['fat'],
            ingredients=json.dumps(recipe_data['ingredients']),
            instructions=json.dumps(recipe_data['instructions']),
            servings=recipe_data.get('servings', 1),
            ready_in_minutes=recipe_data.get('readyInMinutes', 0),
            is_favorite=True,
            is_manual=False
        )
        db.session.add(recipe)
        action = 'hozzáadva'
    
    db.session.commit()
    flash(f'Recept {action} a kedvencekhez!', 'success')
    
    return redirect(request.referrer or url_for('recipes.index'))


@bp.route('/add-manual', methods=['GET', 'POST'])
@login_required
def add_manual():
    if request.method == 'POST':
        name = request.form.get('name')
        calories = float(request.form.get('calories', 0))
        protein = float(request.form.get('protein', 0))
        carbs = float(request.form.get('carbs', 0))
        fat = float(request.form.get('fat', 0))
        servings = int(request.form.get('servings', 1))
        ingredients = request.form.get('ingredients', '')
        instructions = request.form.get('instructions', '')
        image_url = request.form.get('image_url', '')
        
        if not name:
            flash('A recept nevét kötelező megadni!', 'danger')
            return render_template('recipes/add_manual.html')
        
        if not image_url or image_url.strip() == '':
            image_url = 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800'
        
        recipe = Recipe(
            user_id=current_user.id,
            name=name,
            calories=calories,
            protein_g=protein,
            carbs_g=carbs,
            fat_g=fat,
            servings=servings,
            ingredients=ingredients,
            instructions=instructions,
            image_url=image_url,
            is_manual=True,
            is_seed=False,
            is_favorite=False
        )
        
        db.session.add(recipe)
        db.session.commit()
        
        flash(f'Recept "{name}" sikeresen hozzáadva!', 'success')
        return redirect(url_for('recipes.index'))
    
    return render_template('recipes/add_manual.html')


@bp.route('/delete/<int:recipe_id>', methods=['POST'])
@login_required
def delete(recipe_id):
    recipe = Recipe.query.filter_by(id=recipe_id, user_id=current_user.id).first_or_404()
    
    db.session.delete(recipe)
    db.session.commit()
    
    flash(f'Recept "{recipe.name}" törölve!', 'success')
    return redirect(url_for('recipes.index'))



def search_recipes_api(query, number=12):
    url = f"{current_app.config['SPOONACULAR_BASE_URL']}/recipes/complexSearch"
    
    params = {
        'apiKey': current_app.config['SPOONACULAR_API_KEY'],
        'query': query,
        'number': number,
        'addRecipeNutrition': True,
        'fillIngredients': False
    }
    
    try:
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()
        
        results = []
        for recipe in data.get('results', []):
            nutrition = recipe.get('nutrition', {}).get('nutrients', [])
            
            calories = next((n['amount'] for n in nutrition if n['name'] == 'Calories'), 0)
            protein = next((n['amount'] for n in nutrition if n['name'] == 'Protein'), 0)
            carbs = next((n['amount'] for n in nutrition if n['name'] == 'Carbohydrates'), 0)
            fat = next((n['amount'] for n in nutrition if n['name'] == 'Fat'), 0)
            
            results.append({
                'id': recipe['id'],
                'title': recipe['title'],
                'image': recipe.get('image', ''),
                'calories': round(calories, 1),
                'protein': round(protein, 1),
                'carbs': round(carbs, 1),
                'fat': round(fat, 1)
            })
        
        return results
    
    except requests.RequestException as e:
        print(f"API Error: {e}")
        return []


def get_recipe_details_api(recipe_id):
    url = f"{current_app.config['SPOONACULAR_BASE_URL']}/recipes/{recipe_id}/information"
    
    params = {
        'apiKey': current_app.config['SPOONACULAR_API_KEY'],
        'includeNutrition': True
    }
    
    try:
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()
        
        nutrition = data.get('nutrition', {}).get('nutrients', [])
        calories = next((n['amount'] for n in nutrition if n['name'] == 'Calories'), 0)
        protein = next((n['amount'] for n in nutrition if n['name'] == 'Protein'), 0)
        carbs = next((n['amount'] for n in nutrition if n['name'] == 'Carbohydrates'), 0)
        fat = next((n['amount'] for n in nutrition if n['name'] == 'Fat'), 0)
        
        ingredients = [
            f"{ing.get('amount', '')} {ing.get('unit', '')} {ing['name']}"
            for ing in data.get('extendedIngredients', [])
        ]
        
        instructions = []
        for step in data.get('analyzedInstructions', [{}])[0].get('steps', []):
            instructions.append(f"{step['number']}. {step['step']}")
        
        return {
            'id': data['id'],
            'title': data['title'],
            'image': data.get('image', ''),
            'servings': data.get('servings', 1),
            'readyInMinutes': data.get('readyInMinutes', 0),
            'nutrition': {
                'calories': round(calories, 1),
                'protein': round(protein, 1),
                'carbs': round(carbs, 1),
                'fat': round(fat, 1)
            },
            'ingredients': ingredients,
            'instructions': instructions
        }
    
    except requests.RequestException as e:
        print(f"API Error: {e}")
        return None


def get_popular_recipes():
    url = f"{current_app.config['SPOONACULAR_BASE_URL']}/recipes/random"
    
    params = {
        'apiKey': current_app.config['SPOONACULAR_API_KEY'],
        'number': 3,
        'tags': 'healthy'
    }
    
    try:
        response = requests.get(url, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()
        
        results = []
        for recipe in data.get('recipes', []):
            nutrition = recipe.get('nutrition', {}).get('nutrients', [])
            
            calories = next((n['amount'] for n in nutrition if n['name'] == 'Calories'), 0)
            protein = next((n['amount'] for n in nutrition if n['name'] == 'Protein'), 0)
            carbs = next((n['amount'] for n in nutrition if n['name'] == 'Carbohydrates'), 0)
            fat = next((n['amount'] for n in nutrition if n['name'] == 'Fat'), 0)
            
            results.append({
                'id': recipe['id'],
                'title': recipe['title'],
                'image': recipe.get('image', ''),
                'calories': round(calories, 1),
                'protein': round(protein, 1),
                'carbs': round(carbs, 1),
                'fat': round(fat, 1)
            })
        
        return results
    
    except requests.RequestException as e:
        print(f"API Error: {e}")
        return []


@bp.route('/save-api-recipe', methods=['POST'])
@login_required
def save_api_recipe():
    api_id = request.form.get('api_id')
    title = request.form.get('title')
    image = request.form.get('image')
    calories = float(request.form.get('calories', 0))
    protein = float(request.form.get('protein', 0))
    carbs = float(request.form.get('carbs', 0))
    fat = float(request.form.get('fat', 0))
    
    if not api_id or not title:
        flash('Hiányos recept adatok', 'error')
        return redirect(url_for('recipes.index'))
    
    existing = Recipe.query.filter_by(
        user_id=current_user.id,
        api_id=int(api_id)
    ).first()
    
    if existing:
        flash('Ez a recept már hozzá van adva!', 'info')
        return redirect(url_for('recipes.index'))
    
    recipe = Recipe(
        user_id=current_user.id,
        api_id=int(api_id),
        name=title,
        image_url=image if image else '',
        calories=calories,
        protein_g=protein,
        carbs_g=carbs,
        fat_g=fat,
        ingredients='',
        instructions='',
        servings=1,
        ready_in_minutes=0,
        is_manual=False,
        is_seed=False,
        is_favorite=False
    )
    
    db.session.add(recipe)
    db.session.commit()
    
    flash('Recept hozzáadva a listádhoz!', 'success')
    return redirect(url_for('recipes.index'))


@bp.route('/toggle-favorite-seed/<int:recipe_id>', methods=['POST'])
@login_required
def toggle_favorite_seed(recipe_id):
    recipe = Recipe.query.get_or_404(recipe_id)
    
    if recipe.is_seed:
        user_recipe = Recipe.query.filter_by(
            user_id=current_user.id,
            api_id=recipe.id,
            is_seed=False
        ).first()
        
        if user_recipe:
            user_recipe.is_favorite = not user_recipe.is_favorite
            db.session.commit()
            status = "hozzáadva a kedvencekhez" if user_recipe.is_favorite else "eltávolítva a kedvencekből"
            flash(f'Recept {status}!', 'success')
        else:
            new_recipe = Recipe(
                user_id=current_user.id,
                api_id=recipe.id,
                name=recipe.name,
                category=recipe.category,
                image_url=recipe.image_url,
                source_url=recipe.source_url,
                calories=recipe.calories,
                protein_g=recipe.protein_g,
                carbs_g=recipe.carbs_g,
                fat_g=recipe.fat_g,
                ingredients=recipe.ingredients,
                instructions=recipe.instructions,
                servings=recipe.servings,
                ready_in_minutes=recipe.ready_in_minutes,
                is_manual=False,
                is_seed=False,
                is_favorite=True
            )
            db.session.add(new_recipe)
            db.session.commit()
            flash('Kedvencekhez adva!', 'success')
    else:
        if recipe.user_id == current_user.id:
            recipe.is_favorite = not recipe.is_favorite
            db.session.commit()
            status = "hozzáadva a kedvencekhez" if recipe.is_favorite else "eltávolítva a kedvencekből"
            flash(f'Recept {status}!', 'success')
        else:
            flash('Nem jó!', 'error')
    
    return redirect(url_for('recipes.index'))


@bp.route('/favorites')
@login_required
def favorites():
    favorite_recipes = Recipe.query.filter_by(
        user_id=current_user.id,
        is_favorite=True
    ).all()
    
    return render_template('recipes/favorites.html',
                         favorite_recipes=favorite_recipes)


def get_popular_recipes():
    url = f"{current_app.config['SPOONACULAR_BASE_URL']}/recipes/complexSearch"
    
    params = {
        'apiKey': current_app.config['SPOONACULAR_API_KEY'],
        'query': 'healthy meal',
        'number': 3,
        'addRecipeNutrition': True,
        'fillIngredients': False,
        'sort': 'popularity'
    }
    
    try:
        response = requests.get(url, params=params, timeout=5)
        response.raise_for_status()
        data = response.json()
        
        results = []
        for recipe in data.get('results', []):
            nutrition = recipe.get('nutrition', {}).get('nutrients', [])
            
            calories = next((n['amount'] for n in nutrition if n['name'] == 'Calories'), 0)
            protein = next((n['amount'] for n in nutrition if n['name'] == 'Protein'), 0)
            carbs = next((n['amount'] for n in nutrition if n['name'] == 'Carbohydrates'), 0)
            fat = next((n['amount'] for n in nutrition if n['name'] == 'Fat'), 0)
            
            results.append({
                'id': recipe['id'],
                'title': recipe['title'],
                'image': recipe.get('image', ''),
                'calories': round(calories, 1),
                'protein': round(protein, 1),
                'carbs': round(carbs, 1),
                'fat': round(fat, 1)
            })
        
        return results
    except:
        return []
