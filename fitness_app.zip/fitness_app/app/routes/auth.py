from flask import Blueprint, render_template, redirect, url_for, flash, request, session
from flask_login import login_user, logout_user, current_user, login_required
from app import db
from app.models.user import User, UserProfile, UserPreferences
from app.forms import (RegistrationForm, ProfileStep2Form, ProfileStep3Form, 
                       ProfileStep4Form, LoginForm)
import json

bp = Blueprint('auth', __name__)

@bp.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('auth.dashboard'))
    return render_template('index.html')


@bp.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('auth.dashboard'))
    
    form = RegistrationForm()
    
    if form.validate_on_submit():
        user = User(
            username=form.username.data,
            email=form.email.data
        )
        user.set_password(form.password.data)
        
        db.session.add(user)
        db.session.commit()
        
        profile = UserProfile(user_id=user.id, has_completed_first_checkin=False)
        preferences = UserPreferences(user_id=user.id)
        db.session.add(profile)
        db.session.add(preferences)
        db.session.commit()
        
        login_user(user)
        
        flash('Sikeres regisztráció! Folytasd a profil kitöltésével.', 'success')
        return redirect(url_for('auth.profile_step2'))
    
    return render_template('auth/register.html', form=form)


@bp.route('/profile/step2', methods=['GET', 'POST'])
@login_required
def profile_step2():
    form = ProfileStep2Form()
    
    if form.validate_on_submit():
        profile = current_user.profile
        profile.age = form.age.data
        profile.nickname = form.nickname.data
        profile.gender = form.gender.data
        profile.height_cm = form.height_cm.data
        profile.starting_weight_kg = form.starting_weight_kg.data
        profile.current_weight_kg = form.starting_weight_kg.data
        profile.goal = form.goal.data
        
        profile.step2_completed = True
        
        db.session.commit()
        
        flash('Alapadatok mentve! Következő lépés...', 'success')
        return redirect(url_for('auth.profile_step3'))
    
    if current_user.profile and current_user.profile.step2_completed:
        form.age.data = current_user.profile.age
        form.nickname.data = current_user.profile.nickname
        form.gender.data = current_user.profile.gender
        form.height_cm.data = current_user.profile.height_cm
        form.starting_weight_kg.data = current_user.profile.starting_weight_kg
        form.goal.data = current_user.profile.goal
    
    return render_template('auth/profile_step2.html', form=form, step=2)


@bp.route('/profile/step3', methods=['GET', 'POST'])
@login_required
def profile_step3():
    form = ProfileStep3Form()
    
    if request.method == 'POST' and form.validate():
        profile = current_user.profile
        profile.job_activity_level = form.job_activity_level.data
        profile.work_start_time = form.work_start_time.data
        profile.work_end_time = form.work_end_time.data
        
        work_days = request.form.getlist('work_days_per_week')
        profile.work_days_per_week = json.dumps(work_days)
        profile.step3_completed = True
        
        db.session.commit()
        
        flash('Munkahelyi adatok mentve! Utolsó lépés...', 'success')
        return redirect(url_for('auth.profile_step4'))
    
    if current_user.profile and current_user.profile.step3_completed:
        form.job_activity_level.data = current_user.profile.job_activity_level
        form.work_start_time.data = current_user.profile.work_start_time
        form.work_end_time.data = current_user.profile.work_end_time
    
    return render_template('auth/profile_step3.html', form=form, step=3)


def _render_profile_step4(form):
    prefs = current_user.preferences
    profile = current_user.profile
    
    existing_workout_types = []
    existing_training_days = []
    existing_day_workout_mapping = {}
    
    if prefs and prefs.day_workout_mapping:
        try:
            existing_day_workout_mapping = json.loads(prefs.day_workout_mapping)
            existing_workout_types = list(set(existing_day_workout_mapping.values()))
        except:
            pass
    
    if profile and profile.training_days:
        try:
            existing_training_days = json.loads(profile.training_days)
        except:
            pass
    
    return render_template('auth/profile_step4.html', 
                          form=form, 
                          step=4,
                          existing_workout_types=existing_workout_types,
                          existing_training_days=existing_training_days,
                          existing_day_workout_mapping=existing_day_workout_mapping,
                          preferences=prefs,
                          profile=profile)


@bp.route('/profile/step4', methods=['GET', 'POST'])
@login_required
def profile_step4():
    form = ProfileStep4Form()
    
    if request.method == 'POST':
        try:
            form.csrf_token.validate(form)
        except:
            flash('Érvénytelen kérés! Próbáld újra.', 'danger')
            return _render_profile_step4(form)
        
        preferences = current_user.preferences
        profile = current_user.profile
        
        workout_types = request.form.getlist('workout_types')
        
        if not workout_types:
            workout_types = []
        
        preferences.selected_workout_types = json.dumps(workout_types)
        
        if 'walking' in workout_types:
            walking_distance = request.form.get('walking_avg_distance_km')
            if walking_distance:
                avg_distance = float(walking_distance)
                
                if avg_distance < 1 or avg_distance > 20:
                    flash('⚠️ A séta távolság 1 és 20 km között kell legyen!', 'danger')
                    return _render_profile_step4(form)
                
                profile.baseline_walking_distance_km = avg_distance
                profile.current_walking_distance_km = avg_distance
            else:
                profile.baseline_walking_distance_km = 5.0
                profile.current_walking_distance_km = 5.0
        else:
            profile.baseline_walking_distance_km = 3.0
            profile.current_walking_distance_km = 3.0
        
        if 'running' in workout_types:
            pace_min = request.form.get('running_pace_min')
            pace_sec = request.form.get('running_pace_sec')
            
            pace_min_val = int(pace_min) if pace_min else 5
            pace_sec_val = int(pace_sec) if pace_sec else 30
            
            if pace_min_val < 3 or pace_min_val > 12:
                flash('⚠️ A futási tempó 3 és 12 perc között kell legyen!', 'danger')
                return _render_profile_step4(form)
            
            if pace_sec_val < 0 or pace_sec_val > 59:
                flash('⚠️ A másodpercek 0 és 59 között kell legyenek!', 'danger')
                return _render_profile_step4(form)
            
            preferences.running_pace_min = pace_min_val
            preferences.running_pace_sec = pace_sec_val
            
            running_km = request.form.get('running_avg_km')
            running_km_val = float(running_km) if running_km else 5.0
            
            if running_km_val < 1 or running_km_val > 50:
                flash('⚠️ A futási távolság 1 és 50 km között kell legyen!', 'danger')
                return _render_profile_step4(form)
            
            preferences.running_avg_distance_km = running_km_val
            
            profile.baseline_running_distance_km = running_km_val
            profile.current_running_distance_km = running_km_val
            
            pace_min = int(request.form.get('running_pace_min', 0) or 0)
            pace_sec = int(request.form.get('running_pace_sec', 0) or 0)
            pace_total = pace_min + (pace_sec / 60.0)
            
            profile.baseline_running_pace_min = pace_total
            profile.current_running_pace_min = pace_total
        
        if 'bodyweight' in workout_types:
            baseline_reps = {
                'fekvotamasz': int(request.form.get('bodyweight_pushup', 10) or 10),
                'pike-push-up': int(request.form.get('bodyweight_pike_pushup', 8) or 8),
                'tricepsz-nyomas': int(request.form.get('bodyweight_tricep_dips', 10) or 10),
                'guggolas': int(request.form.get('bodyweight_squat', 15) or 15),
                'kitores': int(request.form.get('bodyweight_lunge', 10) or 10),
                'glute-bridge': int(request.form.get('bodyweight_glute_bridge', 15) or 15),
                'superman': int(request.form.get('bodyweight_superman', 12) or 12),
                'reverse-snow-angels': 10,
                'prone-y-raises': 10,
                'plank': int(request.form.get('bodyweight_plank', 30) or 30),
                'mountain-climbers': int(request.form.get('bodyweight_mountain_climbers', 15) or 15),
                'burpee': int(request.form.get('bodyweight_burpee', 8) or 8)
            }
            
            for key, value in baseline_reps.items():
                if value < 1 or value > 300:
                    flash(f'⚠️ A {key} érték 1 és 300 között kell legyen!', 'danger')
                    return _render_profile_step4(form)
            
            profile.baseline_bodyweight_reps = json.dumps(baseline_reps)
            profile.current_bodyweight_reps = json.dumps(baseline_reps)
        
        if 'swimming' in workout_types:
            swim_m = request.form.get('swimming_avg_m')
            swim_m_val = int(swim_m) if swim_m else 1000
            
            if swim_m_val < 100 or swim_m_val > 5000:
                flash('⚠️ Az úszási távolság 100 és 5000 méter között kell legyen!', 'danger')
                return _render_profile_step4(form)
            
            swim_time = request.form.get('swimming_avg_time')
            swim_time_val = int(swim_time) if swim_time else 30
            
            preferences.swimming_avg_distance_m = swim_m_val
            preferences.swimming_avg_time_min = swim_time_val
            
            
            profile.current_swimming_distance_m = swim_m_val
            
            profile.baseline_swimming_distance_m = swim_m_val
        
        if 'cycling' in workout_types:
            cycle_km = request.form.get('cycling_avg_km')
            cycle_km_val = float(cycle_km) if cycle_km else 20.0
            
            if cycle_km_val < 5 or cycle_km_val > 100:
                flash('⚠️ A kerékpározási távolság 5 és 100 km között kell legyen!', 'danger')
                return _render_profile_step4(form)
            
            cycle_time = request.form.get('cycling_avg_time')
            cycle_time_val = int(cycle_time) if cycle_time else 60
            
            preferences.cycling_avg_distance_km = cycle_km_val
            preferences.cycling_avg_time_min = cycle_time_val
            
            
            profile.current_cycling_distance_km = cycle_km_val
            
            profile.baseline_cycling_distance_km = cycle_km_val
        
        training_days_json = request.form.get('training_days_json', '[]')
        day_workout_mapping_json = request.form.get('day_workout_mapping_json', '{}')
        
        try:
            training_days = json.loads(training_days_json)
        except:
            training_days = []
        
        try:
            day_mapping = json.loads(day_workout_mapping_json)
        except:
            day_mapping = {}
        
        if len(workout_types) == 0:
            training_days = []
            day_mapping = {}
        
        profile.training_days = json.dumps(training_days)
        preferences.day_workout_mapping = json.dumps(day_mapping)
        preferences.weekly_workout_count = len(training_days)
        
        preferences.step4_completed = True
        
        try:
            db.session.commit()
            return redirect(url_for('auth.success'))
        except Exception as e:
            db.session.rollback()
            flash(f'Hiba történt a mentés során: {str(e)}', 'danger')
            return _render_profile_step4(form)
    
    return _render_profile_step4(form)


@bp.route('/success')
@login_required
def success():
    return render_template('auth/success.html')


@bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('auth.dashboard'))
    
    form = LoginForm()
    
    if form.validate_on_submit():
        user = User.query.filter(
            (User.username == form.username.data) | 
            (User.email == form.username.data)
        ).first()
        
        if user and user.check_password(form.password.data):
            login_user(user)
            
            next_page = request.args.get('next')
            if next_page:
                return redirect(next_page)
            
            if user.preferences and user.preferences.step4_completed:
                return redirect(url_for('auth.login_success'))
            else:
                return redirect(url_for('auth.profile_step2'))
        else:
            flash('Hibás felhasználónév/email vagy jelszó!', 'danger')
    
    return render_template('auth/login.html', form=form)


@bp.route('/login-success')
@login_required
def login_success():
    return render_template('auth/login_success.html')


@bp.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Sikeresen kijelentkeztél!', 'info')
    return redirect(url_for('auth.index'))


@bp.route('/dashboard')
@login_required
def dashboard():
    return render_template('auth/dashboard.html', user=current_user)
