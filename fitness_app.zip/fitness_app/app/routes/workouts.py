from datetime import datetime, timedelta
from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from app import db
from app.models.user import (
    WorkoutPlan, WorkoutDay, WorkoutDayExercise, Exercise,
    UserWorkoutLog, UserExerciseLog, UserPreferences, UserProfile, Recipe, DailyLog
)
import json

bp = Blueprint('workouts', __name__, url_prefix='/workouts')


def get_recipe_recommendations(meal_type, target_calories, target_protein=None, limit=1):

    category_map = {
        'breakfast': 'breakfast',
        'snack1': 'snack',
        'snack2': 'snack',
        'lunch': 'lunch',
        'dinner': 'dinner'
    }
    
    category = category_map.get(meal_type, meal_type)
    
    cal_min = int(target_calories * 0.7)
    cal_max = int(target_calories * 1.3)

    recipes = Recipe.query.filter(
        Recipe.is_seed == True,
        Recipe.category == category,
        Recipe.calories >= cal_min,
        Recipe.calories <= cal_max
    ).order_by(db.func.random()).limit(limit).all()

    if len(recipes) < limit:
        cal_min = int(target_calories * 0.5)
        cal_max = int(target_calories * 1.5)
        
        recipes = Recipe.query.filter(
            Recipe.is_seed == True,
            Recipe.category == category,
            Recipe.calories >= cal_min,
            Recipe.calories <= cal_max
        ).order_by(db.func.random()).limit(limit).all()
    if len(recipes) < limit:
        recipes = Recipe.query.filter(
            Recipe.is_seed == True,
            Recipe.calories >= cal_min,
            Recipe.calories <= cal_max
        ).order_by(db.func.random()).limit(limit).all()
    
    return recipes


def calculate_day_nutrition(profile, is_work_day, sleep_hours=None, day_weight=None, daily_steps=None, is_training_day=False):
    if day_weight:
        weight = day_weight
    else:
        weight = profile.current_weight_kg or profile.starting_weight_kg or 75
    
    height = profile.height_cm or 170
    age = profile.age or 30
    gender = profile.gender or 'férfi'
    goal = (profile.goal or '').lower()
    target_weight = profile.target_weight_kg or weight
    program_type = profile.program_type or 'weekly'
    is_male = gender in ['férfi', 'male', 'Férfi', 'Male']
    
    if is_male:
        bmr = 10 * weight + 6.25 * height - 5 * age + 5
    else:
        bmr = 10 * weight + 6.25 * height - 5 * age - 161
    
    job_activity = profile.job_activity_level or 'sedentary'
    activity_multipliers = {
        'sedentary': 1.2,      
        'light': 1.375,       
        'moderate': 1.55,      
        'heavy': 1.725,       
    }
    base_tdee = bmr * activity_multipliers.get(job_activity, 1.2)

    work_extra = 0
    if is_work_day:
        work_hours = 8  
        if profile.work_start_time and profile.work_end_time:
            try:
                start_parts = profile.work_start_time.split(':')
                end_parts = profile.work_end_time.split(':')
                start_hour = int(start_parts[0])
                end_hour = int(end_parts[0])
                work_hours = end_hour - start_hour
                if work_hours <= 0:
                    work_hours = 8
            except:
                work_hours = 8
        
        work_burn_per_hour = {
            'sedentary': 10,     
            'light': 30,         
            'moderate': 60,     
            'heavy': 100         
        }
        work_extra = work_burn_per_hour.get(job_activity, 10) * work_hours
    
    day_tdee = base_tdee + work_extra
    
    
    if is_training_day:
        neat_steps = 0
        neat_calories = 0
    else:
        neat_steps = 5000 
        neat_calories = 250  
    
    day_tdee += neat_calories
    
    sleep_adjustment = 0
    if sleep_hours is not None:
        if sleep_hours < 6:
            sleep_adjustment = 50  
        elif sleep_hours > 8:
            sleep_adjustment = -30  
    
    day_tdee += sleep_adjustment
    bmi = weight / ((height / 100) ** 2)
    weight_diff = weight - target_weight
    if program_type == 'monthly':
        weeks_to_goal = 4
    else:
        weeks_to_goal = 1

    
    if goal == 'fogyás' or weight_diff > 0:
        if profile.weekly_weight_goal is not None and profile.weekly_weight_goal > 0:
            weekly_kg_goal = 1.0 if profile.weekly_weight_goal >= 1.0 else 0.5
        else:
            weekly_kg_goal = 0.5 
        
        daily_deficit = int((weekly_kg_goal * 7700) / 7)
        
        target_calories = int(day_tdee - daily_deficit)
        

        print(f"\n💰 TARGET CALORIES DEBUG (FOGYÁS):")
        print(f"  day_tdee (NEAT-tel): {day_tdee}")
        print(f"  daily_deficit: {daily_deficit}")
        print(f"  target_calories: {target_calories}")
        print(f"  weekly_kg_goal: {weekly_kg_goal}\n")
        
    elif goal == 'hízás' or goal == 'izomépítés' or weight_diff < 0:
        if profile.weekly_weight_goal is not None and abs(profile.weekly_weight_goal) > 0:
            weekly_kg_goal = 1.0 if abs(profile.weekly_weight_goal) >= 1.0 else 0.5
        else:
            weekly_kg_goal = 0.5 
        daily_surplus = int((weekly_kg_goal * 7700) / 7)
        target_calories = int(day_tdee + daily_surplus)
        
    else:

        target_calories = int(day_tdee)

    calorie_adjustment = 0
    if program_type == 'monthly' and profile.completed_weeks and profile.completed_weeks > 0:
        calorie_adjustment = getattr(profile, 'calorie_adjustment', 0) or 0
        target_calories += calorie_adjustment
    

    if goal == 'izomépítés' or goal == 'hízás' or weight_diff < 0:
        protein_g = int(weight * 2.0) 
        fat_percent = 0.25
    elif goal == 'fogyás' or weight_diff > 0:
        protein_g = int(weight * 1.8)
        fat_percent = 0.25 
    else:

        protein_g = int(weight * 1.6)
        fat_percent = 0.28

    fat_g = int(target_calories * fat_percent / 9)

    protein_cal = protein_g * 4
    fat_cal = fat_g * 9
    remaining_cal = target_calories - protein_cal - fat_cal
    carbs_g = int(remaining_cal / 4)

    if carbs_g < 80:
        carbs_g = 80
    
    base_water = int(weight * 33)  
    water_ml = base_water
    
    if is_work_day:
        water_ml += 300
    
    if bmi > 25:
        water_ml += 200
    
    if goal == 'fogyás':
        water_ml += 200 

    step_goal = profile.daily_steps_goal or 5000
    
    if program_type == 'monthly' and profile.completed_weeks and profile.completed_weeks > 0:
        steps_adjustment = getattr(profile, 'steps_adjustment', 0) or 0
        step_goal = max(5000, step_goal + steps_adjustment)  # Minimum 5000 lépés
    
    return {
        'calories': target_calories,
        'protein': protein_g,
        'carbs': carbs_g,
        'fat': fat_g,
        'water': water_ml,
        'tdee': int(day_tdee),
        'bmr': int(bmr),
        'bmi': round(bmi, 1),
        'step_goal': step_goal,
        'deficit_or_surplus': int(day_tdee - target_calories) if goal == 'fogyás' else int(target_calories - day_tdee) if goal in ['hízás', 'izomépítés'] else 0,
        'details': {
            'sleep_adj': sleep_adjustment,
            'work_extra': work_extra,
            'neat_steps': neat_steps,
            'neat_calories': neat_calories,
            'weight_diff': round(weight_diff, 1),
            'program_type': program_type,
            'pal_multiplier': activity_multipliers.get(job_activity, 1.2),
            'base_tdee': int(base_tdee),
            'job_activity': job_activity
        }
    }


def adjust_goal_after_checkin(profile, daily_log, workout_type, prefs=None):
    
    if not daily_log or not profile:
        return None
    
    adjustment = None
    intensity = daily_log.exercise_intensity or 'megfelelő'
    
    
    def calculate_progression_rate(profile, prefs, base_rate=5.0):
        
        age = profile.age
        if age < 26:
            age_factor = 1.4  
        elif age < 36:
            age_factor = 1.2  
        elif age < 46:
            age_factor = 1.0  
        elif age < 56:
            age_factor = 0.8 
        else:
            age_factor = 0.6  
        
        experience_level = prefs.experience_level if prefs else None
        experience_level = experience_level or 'közép'
        
        if experience_level in ['kezdő', 'beginner']:
            fitness_factor = 0.8  
        elif experience_level in ['közép', 'intermediate']:
            fitness_factor = 1.0  
        else: 
            fitness_factor = 1.2 

        progression = base_rate * age_factor * fitness_factor
        
        progression = max(3.0, min(7.0, progression))
        
        print(f"  📊 PROGRESSZIÓ SZÁMÍTÁS:")
        print(f"    - Életkor: {age} év → faktor: {age_factor}x")
        print(f"    - Experience: {experience_level} → faktor: {fitness_factor}x")
        print(f"    - Base rate: {base_rate}%")
        print(f"    - Nyers érték: {base_rate * age_factor * fitness_factor:.1f}%")
        print(f"    - Végső (3-7%): {progression:.1f}%")
        
        return progression

    if workout_type == 'running':
        goal_distance = profile.current_running_distance_km or 5.0
        
        if intensity == 'nehéz':
            progression_rate = calculate_progression_rate(profile, prefs, base_rate=5.0)
            multiplier = 1.0 - (progression_rate / 100.0)
            
            new_distance = round(goal_distance * multiplier, 1)
            new_distance = max(new_distance, 2.0)
            profile.current_running_distance_km = new_distance
            
            change_pct = -progression_rate
            calorie_change = int(progression_rate * 8)  
            
            if profile.target_calories:
                profile.target_calories -= calorie_change
            
            adjustment = {
                'type': 'running',
                'message': '😓 NEHÉZ VOLT!',
                'detail': f'{new_distance} km ({change_pct:.1f}%)',
                'old_goal': goal_distance,
                'new_goal': new_distance,
                'change_pct': change_pct,
                'calorie_change': -calorie_change,
                'emoji': '😓'
            }
        
        elif intensity == 'könnyű':
            progression_rate = calculate_progression_rate(profile, prefs, base_rate=5.0)
            multiplier = 1.0 + (progression_rate / 100.0)
            
            new_distance = round(goal_distance * multiplier, 1)
            profile.current_running_distance_km = new_distance
            
            change_pct = +progression_rate
            calorie_change = int(progression_rate * 8)
            
            if profile.target_calories:
                profile.target_calories += calorie_change
            
            adjustment = {
                'type': 'running',
                'message': '💪 KÖNNYŰ VOLT!',
                'detail': f'{new_distance} km (+{change_pct:.1f}%)',
                'old_goal': goal_distance,
                'new_goal': new_distance,
                'change_pct': change_pct,
                'calorie_change': +calorie_change,
                'emoji': '🚀'
            }
        
        else:
            adjustment = {'type': 'running', 'message': '✅ MEGFELELŐ!', 'detail': f'{goal_distance} km (marad)', 'old_goal': goal_distance, 'new_goal': goal_distance, 'change_pct': 0, 'calorie_change': 0, 'emoji': '✅'}
    

    elif workout_type == 'cycling':
        goal_distance = profile.current_cycling_distance_km or 15.0
        
        if intensity == 'nehéz':
            progression_rate = calculate_progression_rate(profile, prefs, base_rate=5.0)
            multiplier = 1.0 - (progression_rate / 100.0)
            
            new_distance = round(goal_distance * multiplier, 1)
            new_distance = max(new_distance, 5.0)
            profile.current_cycling_distance_km = new_distance
            
            change_pct = -progression_rate
            calorie_change = int(progression_rate * 8)
            
            if profile.target_calories:
                profile.target_calories -= calorie_change
            
            adjustment = {
                'type': 'cycling',
                'message': '😓 NEHÉZ VOLT!',
                'detail': f'{new_distance} km ({change_pct:.1f}%)',
                'old_goal': goal_distance,
                'new_goal': new_distance,
                'change_pct': change_pct,
                'calorie_change': -calorie_change,
                'emoji': '😓'
            }
        
        elif intensity == 'könnyű':
            progression_rate = calculate_progression_rate(profile, prefs, base_rate=5.0)
            multiplier = 1.0 + (progression_rate / 100.0)
            
            new_distance = round(goal_distance * multiplier, 1)
            profile.current_cycling_distance_km = new_distance
            
            change_pct = +progression_rate
            calorie_change = int(progression_rate * 8)
            
            if profile.target_calories:
                profile.target_calories += calorie_change
            
            adjustment = {
                'type': 'cycling',
                'message': '💪 KÖNNYŰ VOLT!',
                'detail': f'{new_distance} km (+{change_pct:.1f}%)',
                'old_goal': goal_distance,
                'new_goal': new_distance,
                'change_pct': change_pct,
                'calorie_change': +calorie_change,
                'emoji': '🚴'
            }
        
        else:
            adjustment = {'type': 'cycling', 'message': '✅ MEGFELELŐ!', 'detail': f'{goal_distance} km (marad)', 'old_goal': goal_distance, 'new_goal': goal_distance, 'change_pct': 0, 'calorie_change': 0, 'emoji': '✅'}
    
    elif workout_type == 'swimming':
        goal_distance = profile.current_swimming_distance_m or 800
        
        if intensity == 'nehéz':
            progression_rate = calculate_progression_rate(profile, prefs, base_rate=5.0)
            multiplier = 1.0 - (progression_rate / 100.0)
            
            new_distance = int(round(goal_distance * multiplier, -1)) 
            new_distance = max(new_distance, 200)
            profile.current_swimming_distance_m = new_distance
            
            change_pct = -progression_rate
            calorie_change = int(progression_rate * 8)
            
            if profile.target_calories:
                profile.target_calories -= calorie_change
            
            adjustment = {
                'type': 'swimming',
                'message': '😓 NEHÉZ VOLT!',
                'detail': f'{new_distance} m ({change_pct:.1f}%)',
                'old_goal': goal_distance,
                'new_goal': new_distance,
                'change_pct': change_pct,
                'calorie_change': -calorie_change,
                'emoji': '😓'
            }
        
        elif intensity == 'könnyű':
            progression_rate = calculate_progression_rate(profile, prefs, base_rate=5.0)
            multiplier = 1.0 + (progression_rate / 100.0)
            
            new_distance = int(round(goal_distance * multiplier, -1))
            profile.current_swimming_distance_m = new_distance
            
            change_pct = +progression_rate
            calorie_change = int(progression_rate * 8)
            
            if profile.target_calories:
                profile.target_calories += calorie_change
            
            adjustment = {
                'type': 'swimming',
                'message': '💪 KÖNNYŰ VOLT!',
                'detail': f'{new_distance} m (+{change_pct:.1f}%)',
                'old_goal': goal_distance,
                'new_goal': new_distance,
                'change_pct': change_pct,
                'calorie_change': +calorie_change,
                'emoji': '🏊'
            }
        
        else:
            adjustment = {'type': 'swimming', 'message': '✅ MEGFELELŐ!', 'detail': f'{goal_distance} m (marad)', 'old_goal': goal_distance, 'new_goal': goal_distance, 'change_pct': 0, 'calorie_change': 0, 'emoji': '✅'}
    
    elif workout_type == 'walking':
        goal_distance = profile.current_walking_distance_km or 5.0
        
        if intensity == 'nehéz':
            progression_rate = calculate_progression_rate(profile, prefs, base_rate=5.0)
            multiplier = 1.0 - (progression_rate / 100.0)  
            
            new_distance = round(goal_distance * multiplier, 1)
            new_distance = max(new_distance, 2.0)
            profile.current_walking_distance_km = new_distance
            
            change_pct = -progression_rate
            calorie_change = int(progression_rate * 6) 
            
            print(f"  ✅ ÚJ ÉRTÉK: {new_distance} km ({change_pct:.1f}%)")
            if profile.target_calories:
                profile.target_calories -= calorie_change
            
            adjustment = {
                'type': 'walking',
                'message': '😓 NEHÉZ VOLT!',
                'detail': f'{new_distance} km ({change_pct:.1f}%)',
                'old_goal': goal_distance,
                'new_goal': new_distance,
                'change_pct': change_pct,
                'calorie_change': -calorie_change,
                'emoji': '😓'
            }
        
        elif intensity == 'könnyű':
            progression_rate = calculate_progression_rate(profile, prefs, base_rate=5.0)
            multiplier = 1.0 + (progression_rate / 100.0) 
            
            new_distance = round(goal_distance * multiplier, 1)
            profile.current_walking_distance_km = new_distance
            
            change_pct = +progression_rate
            calorie_change = int(progression_rate * 6)  
            
            print(f"  ✅ ÚJ ÉRTÉK: {new_distance} km (+{change_pct:.1f}%)")
            if profile.target_calories:
                profile.target_calories += calorie_change
            
            adjustment = {
                'type': 'walking',
                'message': '💪 KÖNNYŰ VOLT!',
                'detail': f'{new_distance} km (+{change_pct:.1f}%)',
                'old_goal': goal_distance,
                'new_goal': new_distance,
                'change_pct': change_pct,
                'calorie_change': +calorie_change,
                'emoji': '🚶'
            }
        
        else:
            print(f"  ⚠️ MEGFELELŐ - érték marad: {goal_distance} km")
            adjustment = {'type': 'walking', 'message': '✅ MEGFELELŐ!', 'detail': f'{goal_distance} km (marad)', 'old_goal': goal_distance, 'new_goal': goal_distance, 'change_pct': 0, 'calorie_change': 0, 'emoji': '✅'}

    elif workout_type == 'bodyweight':
        if daily_log.bodyweight_performance:
            try:
                import json
                performance = json.loads(daily_log.bodyweight_performance)
                current_reps = {}
                if profile.current_bodyweight_reps:
                    current_reps = json.loads(profile.current_bodyweight_reps)
                
                age = profile.age if profile and profile.age else 30
                if age < 40:
                    increase_amount = 10
                    decrease_amount = 5
                else:
                    increase_amount = 5
                    decrease_amount = 3
                
                new_reps = {}
                total_changes = 0
                
                print(f"💪 SZABADSÚLY PROGRESSZIÓ:")
                print(f"  - életkor: {age} év")
                print(f"  - ugrás mérték: +{increase_amount} / -{decrease_amount}")
                print(f"  - intensity: {intensity}")
                
                for exercise_id, actual_reps in performance.items():
                    goal_reps = current_reps.get(exercise_id, 10)
                    
                    if intensity == 'nehéz':
                        new_reps[exercise_id] = max(goal_reps - decrease_amount, 5)
                        change = new_reps[exercise_id] - goal_reps
                        total_changes += change
                        print(f"  - {exercise_id}: {goal_reps} → {new_reps[exercise_id]} ({change:+d})")
                        
                    elif intensity == 'könnyű':
                        new_reps[exercise_id] = goal_reps + increase_amount
                        change = increase_amount
                        total_changes += change
                        print(f"  - {exercise_id}: {goal_reps} → {new_reps[exercise_id]} (+{change})")
                        
                    else: 
                        new_reps[exercise_id] = goal_reps
                        print(f"  - {exercise_id}: {goal_reps} (változatlan)")
                
                profile.current_bodyweight_reps = json.dumps(new_reps)

                calorie_change = 0
                if total_changes > 3:
                    calorie_change = min(int(total_changes * 1.5), 80)  
                    if profile.target_calories:
                        profile.target_calories += calorie_change
                elif total_changes < -3:
                    calorie_change = max(int(total_changes * 1.5), -80) 
                    if profile.target_calories:
                        profile.target_calories += calorie_change 
                
                print(f"  ✅ Összes változás: {total_changes:+d} ismétlés")
                print(f"  ✅ Kalória változás: {calorie_change:+d} kcal")
                
                num_exercises = len(performance)
                avg_change_per_ex = total_changes / num_exercises if num_exercises > 0 else 0
                
                if total_changes > 0:
                    adjustment = {
                        'type': 'bodyweight',
                        'message': '💪 KÖNNYŰ VOLT!',
                        'detail': f'+{total_changes} ismétlés összesen ({num_exercises} gyakorlat)',
                        'old_goal': num_exercises,
                        'new_goal': num_exercises,
                        'change_pct': round(avg_change_per_ex),
                        'calorie_change': calorie_change,
                        'emoji': '🔥'
                    }
                elif total_changes < 0:
                    adjustment = {
                        'type': 'bodyweight',
                        'message': '😓 NEHÉZ VOLT!',
                        'detail': f'{total_changes} ismétlés csökkentés ({num_exercises} gyakorlat)',
                        'old_goal': num_exercises,
                        'new_goal': num_exercises,
                        'change_pct': round(avg_change_per_ex),
                        'calorie_change': calorie_change,
                        'emoji': '😓'
                    }
                else:
                    adjustment = {
                        'type': 'bodyweight',
                        'message': '✅ MEGFELELŐ!',
                        'detail': 'Stabil teljesítmény',
                        'old_goal': num_exercises,
                        'new_goal': num_exercises,
                        'change_pct': 0,
                        'calorie_change': 0,
                        'emoji': '💪'
                    }
            except (json.JSONDecodeError, AttributeError):
                pass
    
    return adjustment


def get_user_workout_plan():
    profile = current_user.profile
    prefs = current_user.preferences

    if not profile:
        return None
    
    goal_map = {
        'fogyás': 'weight_loss',
        'fogyas': 'weight_loss', 
        'izomépítés': 'muscle_gain',
        'izomepites': 'muscle_gain',
        'fenntartás': 'maintenance',
        'fenntartas': 'maintenance',
        'karban tartás': 'maintenance',
        'karban tartas': 'maintenance',
        'muscle_gain': 'muscle_gain',
        'weight_loss': 'weight_loss',
        'maintenance': 'maintenance'
    }
    
    exp_map = {
        'kezdő': 'beginner',
        'kezdo': 'beginner',
        'haladó': 'intermediate',
        'halado': 'intermediate',
        'profi': 'advanced',
        'beginner': 'beginner',
        'intermediate': 'intermediate',
        'advanced': 'advanced'
    }
    
    user_goal = 'maintenance'
    if profile and profile.goal:
        user_goal = goal_map.get(profile.goal.lower(), 'maintenance')
    
    user_exp = 'beginner'
    if prefs and prefs.experience_level:
        user_exp = exp_map.get(prefs.experience_level.lower(), 'beginner')
    if prefs and prefs.selected_workout_types:
        try:
            exercises = json.loads(prefs.selected_workout_types) if isinstance(prefs.selected_workout_types, str) else prefs.selected_workout_types
            if isinstance(exercises, list):
                if len(exercises) == 0:
                    return 'none'
                elif len(exercises) == 1:
                    return exercises[0]
                else:
                    return 'multi'
        except (json.JSONDecodeError, TypeError):
            pass
    
    return 'none'


def get_todays_workout(plan):
    if not plan:
        return None
    
    today = datetime.now().weekday() + 1
    
    workout_days = WorkoutDay.query.filter_by(workout_plan_id=plan.id).order_by(WorkoutDay.day_number).all()
    
    if not workout_days:
        return None
    
    for day in workout_days:
        if day.day_number == today:
            return day
    
    for day in workout_days:
        if day.day_number > today:
            return day
    
    return workout_days[0]


def get_week_stats():
    week_start = datetime.now() - timedelta(days=datetime.now().weekday())
    week_start = week_start.replace(hour=0, minute=0, second=0, microsecond=0)
    
    completed_this_week = UserWorkoutLog.query.filter(
        UserWorkoutLog.user_id == current_user.id,
        UserWorkoutLog.completed == True,
        UserWorkoutLog.date >= week_start
    ).count()
    
    total_workouts = UserWorkoutLog.query.filter(
        UserWorkoutLog.user_id == current_user.id,
        UserWorkoutLog.completed == True
    ).count()
    streak = 0
    check_date = datetime.now().date()
    
    while True:
        log = UserWorkoutLog.query.filter(
            UserWorkoutLog.user_id == current_user.id,
            UserWorkoutLog.completed == True,
            db.func.date(UserWorkoutLog.date) == check_date
        ).first()
        
        if log:
            streak += 1
            check_date -= timedelta(days=1)
        else:
            check_date -= timedelta(days=1)
            log2 = UserWorkoutLog.query.filter(
                UserWorkoutLog.user_id == current_user.id,
                UserWorkoutLog.completed == True,
                db.func.date(UserWorkoutLog.date) == check_date
            ).first()
            if not log2:
                break
    
    return {
        'completed_this_week': completed_this_week,
        'total_workouts': total_workouts,
        'streak': streak
    }


@bp.route('/')
@login_required
def index():
    from datetime import date, timedelta
    
    profile = current_user.profile
    
    if not profile:
        flash('Először töltsd ki a profilodat!', 'warning')
        return redirect(url_for('auth.profile_step2'))
    
    if not profile.program_type:
        return render_template('workouts/view_select.html', profile=profile)
    

    today = date.today()
    program_start = profile.program_start_date or today

    program_end = program_start + timedelta(days=6)

    next_week_start = program_start + timedelta(days=7)
    
    completed_checkins = DailyLog.query.filter(
        DailyLog.user_id == current_user.id,
        DailyLog.date >= program_start,
        DailyLog.date <= program_end,
        DailyLog.completed == True
    ).count()
  
    if completed_checkins >= 7 and today >= next_week_start:
        return redirect(url_for('workouts.weekly_summary'))
    
    plan = get_user_workout_plan()

    from datetime import datetime as dt
    day_map = {0: 'monday', 1: 'tuesday', 2: 'wednesday', 3: 'thursday', 
               4: 'friday', 5: 'saturday', 6: 'sunday'}
    today_day = day_map[dt.now().weekday()]

    prefs = current_user.preferences
    today_workout_type = None
    
    if prefs and prefs.day_workout_mapping:
        try:
            mapping = json.loads(prefs.day_workout_mapping)
            today_workout_type = mapping.get(today_day, None)
        except:
            pass
    
    return redirect(url_for('workouts.day_view', day=today_day))


@bp.route('/set-view/<view_type>')
@login_required
def set_view(view_type):
    if view_type in ['daily', 'weekly']:
        profile = current_user.profile
        if profile:
            profile.view_preference = view_type
            db.session.commit()
    
    return redirect(url_for('workouts.index'))


@bp.route('/setup-program')
@login_required
def setup_program():
    from datetime import date
    
    profile = current_user.profile
    if not profile:
        flash('Először töltsd ki a profilodat!', 'warning')
        return redirect(url_for('auth.profile_step2'))
    
    program_type = request.args.get('type', 'weekly')
    target_kg = float(request.args.get('target', 0))
    continue_program = request.args.get('continue', '0') == '1'
    

    profile.program_type = program_type
    profile.program_target_kg = target_kg

    profile.weekly_weight_goal = abs(target_kg) 
    
    print(f"\n🎯 CÉL MENTÉSE")
    print(f"  Program típus: {program_type}")
    print(f"  User által megadott érték: {target_kg} kg")
    print(f"  Értelmezés: {abs(target_kg)} kg/hét")
    if program_type == 'monthly':
        print(f"  Havi összesen: {abs(target_kg) * 4} kg (4 hét)")
    print(f"  weekly_weight_goal: {profile.weekly_weight_goal} kg/hét\n")
    

    if not continue_program:
        today = date.today()
        
        print(f"\n📅 PROGRAM START DATE")
        print(f"  Ma: {today} ({today.strftime('%A')})")
        print(f"  Program kezdés: {today}\n")
        
        profile.program_start_date = today
        profile.program_start_weight = profile.current_weight_kg or profile.starting_weight_kg
        profile.completed_weeks = 0
        profile.calorie_adjustment = 0 
        profile.steps_adjustment = 0   
    
    current_weight = profile.current_weight_kg or profile.starting_weight_kg
    profile.target_weight_kg = current_weight + target_kg
    
    profile.view_preference = 'weekly' 
    
    db.session.commit()
    
    flash('Program sikeresen elindítva! 🎉', 'success')
    return redirect(url_for('workouts.index'))


@bp.route('/weekly-summary')
@login_required
def weekly_summary():

    from datetime import date, timedelta
    
    profile = current_user.profile
    if not profile:
        return redirect(url_for('auth.profile_step2'))
    
    program_start = profile.program_start_date or date.today()
    program_end = program_start + timedelta(days=6)
    
    logs = DailyLog.query.filter(
        DailyLog.user_id == current_user.id,
        DailyLog.date >= program_start,
        DailyLog.date <= program_end
    ).all()
    

    all_complete = True
    for i in range(7):
        day_date = program_start + timedelta(days=i)
        log = DailyLog.query.filter_by(user_id=current_user.id, date=day_date).first()
        if not log or not log.completed:
            all_complete = False
            break
    
    if not all_complete:
        flash('A heti összesítő csak akkor érhető el, ha minden nap check-in-je kész!', 'warning')
        return redirect(url_for('workouts.index'))

    total_steps = sum(log.steps_completed or 0 for log in logs)
    total_km = round(total_steps * 0.0008, 1)
    total_calories_burned = int(total_steps * 0.04)
    total_walking_minutes = sum(log.walking_minutes or 0 for log in logs)
    total_water = sum(log.water_ml or 0 for log in logs)
    

    total_steps_goal = sum(log.steps_goal or 5000 for log in logs)
    total_calories_goal = sum(log.calories_goal or 2000 for log in logs)
    total_calories_consumed = sum(log.calories_consumed or 0 for log in logs)

    steps_achievement = min(100, int((total_steps / total_steps_goal * 100) if total_steps_goal else 0))
    calories_achievement = min(100, int((total_calories_consumed / total_calories_goal * 100) if total_calories_goal else 0))

    first_weight = None
    last_weight = None
    for log in sorted(logs, key=lambda x: x.date):
        if log.weight_kg:
            if not first_weight:
                first_weight = log.weight_kg
            last_weight = log.weight_kg
    
    weight_change = round((last_weight - first_weight), 1) if first_weight and last_weight else 0
    

    sleep_logs = [log.sleep_hours for log in logs if log.sleep_hours]
    avg_sleep = round(sum(sleep_logs) / len(sleep_logs), 1) if sleep_logs else 0
    

    current_weight = last_weight or profile.current_weight_kg or profile.starting_weight_kg
    target_weight = profile.target_weight_kg or current_weight
    weight_to_goal = round(current_weight - target_weight, 1)

    program_type = profile.program_type or 'weekly'
    completed_weeks = profile.completed_weeks or 0
    
    day_names_hu = ['Hétfő', 'Kedd', 'Szerda', 'Csütörtök', 'Péntek', 'Szombat', 'Vasárnap']
    daily_labels = []
    daily_steps = []
    daily_goals = []
    
    for i in range(7):
        day_date = program_start + timedelta(days=i)
        weekday = day_date.weekday()
        daily_labels.append(day_names_hu[weekday][:3]) 
        
        log = next((l for l in logs if l.date == day_date), None)
        if log:
            daily_steps.append(log.steps_completed or 0)
            daily_goals.append(log.steps_goal or 5000)
        else:
            daily_steps.append(0)
            daily_goals.append(10000)
    
    preferences = current_user.preferences
    workout_progress = {}
    
    if preferences:
        selected_types_str = preferences.selected_workout_types or '[]'
        try:
            selected_types = json.loads(selected_types_str)
        except:
            selected_types = []
        

        if 'running' in selected_types:
            baseline_km = profile.baseline_running_distance_km or 0
            current_km = profile.current_running_distance_km or baseline_km
            baseline_pace = profile.baseline_running_pace_min or 0
            current_pace = profile.current_running_pace_min or baseline_pace
            
            if baseline_km > 0:
                change_percent = round(((current_km - baseline_km) / baseline_km) * 100, 1)

                pace_change = 0
                pace_change_percent = 0
                baseline_pace_formatted = ""
                current_pace_formatted = ""
                
                if baseline_pace > 0:
                    pace_change = round(current_pace - baseline_pace, 1)
                    pace_change_percent = round(((current_pace - baseline_pace) / baseline_pace) * 100, 1)
                    
                    baseline_min = int(baseline_pace)
                    baseline_sec = int((baseline_pace % 1) * 60)
                    baseline_pace_formatted = f"{baseline_min}:{baseline_sec:02d}"
                    
                    current_min = int(current_pace)
                    current_sec = int((current_pace % 1) * 60)
                    current_pace_formatted = f"{current_min}:{current_sec:02d}"
                
                workout_progress['running'] = {
                    'baseline': baseline_km,
                    'current': current_km,
                    'change': round(current_km - baseline_km, 1),
                    'change_percent': change_percent,
                    'baseline_pace': baseline_pace,
                    'current_pace': current_pace,
                    'baseline_pace_formatted': baseline_pace_formatted,
                    'current_pace_formatted': current_pace_formatted,
                    'pace_change': pace_change,
                    'pace_change_percent': pace_change_percent
                }

        if 'cycling' in selected_types:
            baseline_km = profile.baseline_cycling_distance_km or 0
            current_km = profile.current_cycling_distance_km or baseline_km
            if baseline_km > 0:
                change_percent = round(((current_km - baseline_km) / baseline_km) * 100, 1)
                workout_progress['cycling'] = {
                    'baseline': baseline_km,
                    'current': current_km,
                    'change': round(current_km - baseline_km, 1),
                    'change_percent': change_percent
                }
        
        if 'walking' in selected_types:
            baseline_km = profile.baseline_walking_distance_km or 0
            current_km = profile.current_walking_distance_km or baseline_km
            if baseline_km > 0:
                change_percent = round(((current_km - baseline_km) / baseline_km) * 100, 1)
                workout_progress['walking'] = {
                    'baseline': baseline_km,
                    'current': current_km,
                    'change': round(current_km - baseline_km, 1),
                    'change_percent': change_percent
                }
        
        if 'swimming' in selected_types:
            baseline_m = profile.baseline_swimming_distance_m or 0
            current_m = profile.current_swimming_distance_m or baseline_m
            if baseline_m > 0:
                change_percent = round(((current_m - baseline_m) / baseline_m) * 100, 1)
                workout_progress['swimming'] = {
                    'baseline': baseline_m,
                    'current': current_m,
                    'change': round(current_m - baseline_m, 0),
                    'change_percent': change_percent
                }
        
        if 'bodyweight' in selected_types:
            baseline_reps_str = profile.baseline_bodyweight_reps or '{}'
            current_reps_str = profile.current_bodyweight_reps or baseline_reps_str
            try:
                baseline_reps = json.loads(baseline_reps_str)
                current_reps = json.loads(current_reps_str)
            except:
                baseline_reps = {}
                current_reps = {}
            
            exercises_progress = {}
            exercise_names = {
                'fekvotamasz': 'Fekvőtámasz',
                'pike-push-up': 'Pike Push-up',
                'tricepsz-nyomas': 'Tricepsz',
                'guggolas': 'Guggolás',
                'kitores': 'Kitörés',
                'glute-bridge': 'Glute Bridge',
                'superman': 'Superman',
                'plank': 'Plank',
                'mountain-climbers': 'Mountain Climbers',
                'burpee': 'Burpee'
            }
            
            for key, name in exercise_names.items():
                baseline_val = baseline_reps.get(key, 0)
                current_val = current_reps.get(key, baseline_val)
                if baseline_val > 0:
                    change_percent = round(((current_val - baseline_val) / baseline_val) * 100, 1)
                    exercises_progress[key] = {
                        'name': name,
                        'baseline': baseline_val,
                        'current': current_val,
                        'change': current_val - baseline_val,
                        'change_percent': change_percent
                    }
            
            if exercises_progress:
                avg_change = round(sum(ex['change_percent'] for ex in exercises_progress.values()) / len(exercises_progress), 1)
                workout_progress['bodyweight'] = {
                    'exercises': exercises_progress,
                    'avg_change_percent': avg_change
                }
    
    weekly_kg_goal = profile.weekly_weight_goal if profile.weekly_weight_goal else 0.5
    
    return render_template('workouts/weekly_summary.html',
                         profile=profile,
                         program_start=program_start,
                         program_end=program_end,
                         total_steps=total_steps,
                         total_km=total_km,
                         total_calories_burned=total_calories_burned,
                         total_walking_minutes=total_walking_minutes,
                         total_water=total_water,
                         weight_change=weight_change,
                         steps_achievement=steps_achievement,
                         calories_achievement=calories_achievement,
                         total_calories_consumed=total_calories_consumed,
                         total_calories_goal=total_calories_goal,
                         avg_sleep=avg_sleep,
                         current_weight=current_weight,
                         target_weight=target_weight,
                         weight_to_goal=weight_to_goal,
                         program_type=program_type,
                         completed_weeks=completed_weeks,
                         daily_labels=daily_labels,
                         daily_steps=daily_steps,
                         daily_goals=daily_goals,
                         workout_progress=workout_progress,
                         selected_workout_types=selected_types if preferences else [],
                         weekly_kg_goal=weekly_kg_goal)


@bp.route('/finalize-week')
@login_required
def finalize_week():
    from datetime import date, timedelta
    from app.models.user import WeeklyResult
    
    profile = current_user.profile
    if not profile:
        return redirect(url_for('auth.profile_step2'))
    
    program_start = profile.program_start_date or date.today()
    program_end = program_start + timedelta(days=6)
    program_type = profile.program_type or 'weekly'
    
    logs = DailyLog.query.filter(
        DailyLog.user_id == current_user.id,
        DailyLog.date >= program_start,
        DailyLog.date <= program_end
    ).all()
    

    all_done = True
    for i in range(7):
        day_date = program_start + timedelta(days=i)
        day_log = DailyLog.query.filter_by(
            user_id=current_user.id,
            date=day_date
        ).first()
        
        if not day_log or not day_log.completed:
            all_done = False
            break
    
    if not all_done:
        flash('A véglegesítéshez minden nap check-in-je szükséges!', 'warning')
        return redirect(url_for('workouts.index'))
    
    total_steps = sum(log.steps_completed or 0 for log in logs)
    total_km = round(total_steps * 0.0008, 1)
    total_calories_burned = int(total_steps * 0.04)
    total_walking_minutes = sum(log.walking_minutes or 0 for log in logs)
    total_water = sum(log.water_ml or 0 for log in logs)
    total_steps_goal = sum(log.steps_goal or 5000 for log in logs)
    steps_achievement = min(100, int((total_steps / total_steps_goal * 100) if total_steps_goal else 0))
    
    first_weight = None
    last_weight = None
    for log in sorted(logs, key=lambda x: x.date):
        if log.weight_kg:
            if not first_weight:
                first_weight = log.weight_kg
            last_weight = log.weight_kg
    weight_change = round((last_weight - first_weight), 1) if first_weight and last_weight else 0
    
    sleep_logs = [log.sleep_hours for log in logs if log.sleep_hours]
    avg_sleep = round(sum(sleep_logs) / len(sleep_logs), 1) if sleep_logs else 0
    
    day_names_hu = ['Hétfő', 'Kedd', 'Szerda', 'Csütörtök', 'Péntek', 'Szombat', 'Vasárnap']
    daily_labels = []
    daily_steps = []
    for i in range(7):
        day_date = program_start + timedelta(days=i)
        weekday = day_date.weekday()
        daily_labels.append(day_names_hu[weekday][:3])
        log = next((l for l in logs if l.date == day_date), None)
        daily_steps.append(log.steps_completed or 0 if log else 0)
    
    weeks_completed = profile.completed_weeks or 0
    result = WeeklyResult(
        user_id=current_user.id,
        week_start=program_start,
        week_end=program_end,
        week_number=weeks_completed + 1,
        program_type=program_type,
        total_steps=total_steps,
        total_km=total_km,
        total_calories_burned=total_calories_burned,
        total_walking_minutes=total_walking_minutes,
        total_water_ml=total_water,
        steps_goal=total_steps_goal,
        steps_achievement=steps_achievement,
        start_weight=first_weight,
        end_weight=last_weight,
        weight_change=weight_change,
        avg_sleep=avg_sleep,
        daily_steps_json=json.dumps(daily_steps),
        daily_labels_json=json.dumps(daily_labels)
    )
    db.session.add(result)
    
    DailyLog.query.filter(
        DailyLog.user_id == current_user.id,
        DailyLog.date >= program_start,
        DailyLog.date <= program_end
    ).delete()
    
    if program_type == 'monthly':
        weeks_completed += 1
        profile.completed_weeks = weeks_completed
        
        optimization_msg = ""
        if weeks_completed < 4:
            goal = profile.goal or 'fogyás'
            weekly_goal = profile.weekly_weight_goal or 1.0  
            
            print(f"\n📊 HETI ÖSSZESÍTŐ OPTIMALIZÁLÁS")
            print(f"  Heti cél (user): {weekly_goal} kg/hét")
            print(f"  Valós változás: {weight_change} kg")
            
            if goal == 'fogyás':
                if weight_change >= 0:
                    profile.calorie_adjustment = (profile.calorie_adjustment or 0) - 150
                    optimization_msg = f"🔧 Nem fogyott elég: -150 kcal"
                    print(f"  ❌ Nem fogyott! Cél: -{weekly_goal} kg, valós: {weight_change} kg")
                    
                elif weight_change < -(weekly_goal * 1.2):
                    profile.calorie_adjustment = (profile.calorie_adjustment or 0) + 150
                    optimization_msg = f"🔧 Túl gyors fogyás! +150 kcal az egészséges tempóért"
                    print(f"  ⚠️ Túl gyors! Cél: -{weekly_goal} kg, valós: {weight_change} kg")
                    
                else:
                    optimization_msg = f"✅ Tökéletes ütem! ({weight_change}kg) Változatlan beállítások."
                    print(f"  ✅ Megfelelő! Cél: -{weekly_goal} kg, valós: {weight_change} kg")
                    
            elif goal in ['hízás', 'izomépítés']:
                if weight_change <= 0:
                    profile.calorie_adjustment = (profile.calorie_adjustment or 0) + 200
                    optimization_msg = f"🔧 Automatikus módosítás: +200 kcal"
                    print(f"  ❌ Nem hízott! Cél: +{weekly_goal} kg, valós: {weight_change} kg")
                    
                elif weight_change > (weekly_goal * 1.5):
                    profile.calorie_adjustment = (profile.calorie_adjustment or 0) - 100
                    optimization_msg = f"🔧 Kontrollált ütem: -100 kcal a minőségi tömegért"
                    print(f"  ⚠️ Túl gyors! Cél: +{weekly_goal} kg, valós: {weight_change} kg")
                    
                else:

                    optimization_msg = f"✅ Tökéletes ütem! (+{weight_change}kg) Változatlan beállítások."
                    print(f"  ✅ Megfelelő! Cél: +{weekly_goal} kg, valós: {weight_change} kg")
            
            else:
                if abs(weight_change) > 0.5:
                    if weight_change > 0:
                        profile.calorie_adjustment = (profile.calorie_adjustment or 0) - 100
                        optimization_msg = f"🔧 Korrekció: -100 kcal (súly nőtt)"
                    else:
                        profile.calorie_adjustment = (profile.calorie_adjustment or 0) + 100
                        optimization_msg = f"🔧 Korrekció: +100 kcal (súly csökkent)"
                else:
                    optimization_msg = f"✅ Stabil súly! ({weight_change}kg) Változatlan beállítások."
            
            print(f"  Optimization: {optimization_msg}\n")
            
        
        if weeks_completed >= 4:
            DailyLog.query.filter_by(user_id=current_user.id).delete()
            
            flash('🎉 Gratulálunk! Sikeresen befejezted a havi programot!', 'success')
            profile.completed_weeks = 0
            profile.program_start_date = None
            profile.program_type = None
            db.session.commit()
            return redirect(url_for('auth.dashboard'))
        else:
            next_week_start = program_end + timedelta(days=1) 
            base_msg = f'✅ {weeks_completed}/4 hét kész!'
            if optimization_msg:
                flash(f'{base_msg} {optimization_msg}', 'info')
            else:
                flash(f'{base_msg} Folytatás változatlan beállításokkal.', 'success')
            profile.program_start_date = next_week_start  
            db.session.commit()
            return redirect(url_for('workouts.index'))
    else:
        DailyLog.query.filter_by(user_id=current_user.id).delete()
        
        profile.completed_weeks = (profile.completed_weeks or 0) + 1
        profile.program_start_date = None 
        profile.program_type = None
        db.session.commit()
        
        flash('🎉 Gratulálunk! Sikeresen befejezted a hetet!', 'success')
        return redirect(url_for('auth.dashboard'))


@bp.route('/reset-program', methods=['GET', 'POST'])
@login_required
def reset_program():
    from datetime import date
    
    profile = current_user.profile
    if not profile:
        return redirect(url_for('auth.profile_step2'))

    profile.selected_plan = None
    profile.program_type = None
    profile.program_start_date = None
    profile.program_weeks = None
    profile.completed_weeks = 0
    
    if profile.baseline_running_distance_km:
        profile.current_running_distance_km = profile.baseline_running_distance_km
    if profile.baseline_running_pace_min:
        profile.current_running_pace_min = profile.baseline_running_pace_min
    
    if profile.baseline_cycling_distance_km:
        profile.current_cycling_distance_km = profile.baseline_cycling_distance_km
    
    if profile.baseline_swimming_distance_m:
        profile.current_swimming_distance_m = profile.baseline_swimming_distance_m
    
    if profile.baseline_walking_distance_km:
        profile.current_walking_distance_km = profile.baseline_walking_distance_km
    
    if profile.baseline_bodyweight_reps:
        profile.current_bodyweight_reps = profile.baseline_bodyweight_reps
    
    profile.has_completed_first_checkin = False
    
    DailyLog.query.filter_by(user_id=current_user.id).delete()
    
    db.session.commit()
    
    flash('Az edzésterv és a progresszió újraindult!', 'info')
    return redirect(url_for('workouts.index'))


@bp.route('/save-daily-input/<day>', methods=['POST'])
@login_required
def save_daily_input(day):
    from datetime import date, timedelta
    
    profile = current_user.profile
    if not profile:
        return redirect(url_for('workouts.day_view', day=day))
    
    program_start = profile.program_start_date or date.today()
    

    day_names_en = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']
    program_day_map = {}
    for i in range(7):
        d = program_start + timedelta(days=i)
        d_weekday = d.weekday()
        d_name = day_names_en[d_weekday]
        program_day_map[d_name] = d
    
    day_date = program_day_map.get(day, program_start)
    

    daily_log = DailyLog.query.filter_by(
        user_id=current_user.id,
        date=day_date
    ).first()
    
    if not daily_log:
        daily_log = DailyLog(user_id=current_user.id, date=day_date)
        db.session.add(daily_log)
    

    weight = request.form.get('weight')
    if weight:
        new_weight = float(weight)
        

        prev_day_date = day_date - timedelta(days=1)
        prev_log = DailyLog.query.filter_by(user_id=current_user.id, date=prev_day_date).first()
        

        if prev_log and prev_log.weight_kg:
            reference_weight = prev_log.weight_kg
        elif profile.program_start_weight:
            reference_weight = profile.program_start_weight
        else:
            reference_weight = profile.starting_weight_kg or 75
        

        max_daily_change = 1.5
        
        if abs(new_weight - reference_weight) > max_daily_change:
            flash(f'⚠️ Figyelem: A súly ({new_weight}kg) túl sokat változott az előző méréshez képest ({reference_weight}kg). Maximum ±{max_daily_change}kg eltérés megengedett naponta.', 'warning')
            return redirect(url_for('workouts.day_view', day=day))
        

        if new_weight < 30 or new_weight > 300:
            flash('⚠️ Érvénytelen súly! A súlynak 30-300 kg között kell lennie.', 'danger')
            return redirect(url_for('workouts.day_view', day=day))
        
        daily_log.weight_kg = new_weight
        profile.current_weight_kg = new_weight
    
    sleep = request.form.get('sleep_hours')
    if sleep:
        daily_log.sleep_hours = float(sleep)
    meals_count = request.form.get('meals_count')
    if meals_count:
        daily_log.meals_count = int(meals_count)
    else:
        daily_log.meals_count = 4
    
    work_days = []
    if profile.work_days_per_week:
        try:
            work_days = json.loads(profile.work_days_per_week)
        except:
            work_days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday']
    else:
        work_days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday']
    daily_log.is_work_day = day in work_days
    
    db.session.commit()
    db.session.refresh(daily_log)
    db.session.refresh(profile)
    
    flash('Napi adatok mentve!', 'success')
    
    response = redirect(url_for('workouts.day_view', day=day))
    response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '0'
    return response



@bp.route('/daily-checkin', methods=['GET', 'POST'])
@bp.route('/daily-checkin/<day>', methods=['GET', 'POST'])
@login_required
def daily_checkin(day=None):
    from datetime import date, timedelta
    from app.models.user import DailyLog
    
    profile = current_user.profile
    if not profile:
        return redirect(url_for('auth.profile_step2'))
    
    program_start = profile.program_start_date or date.today()

    if day is None:
        checkin_date = date.today()
    else:
        day_names_en_calc = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']
        program_day_map = {}
        for i in range(7):
            d = program_start + timedelta(days=i)
            d_weekday = d.weekday()
            d_name = day_names_en_calc[d_weekday]
            program_day_map[d_name] = d
        
        checkin_date = program_day_map.get(day, date.today())
    
    daily_log = DailyLog.query.filter_by(
        user_id=current_user.id,
        date=checkin_date
    ).first()
    
    prefs = current_user.preferences
    today_workout_type = None
    training_days = []
    day_workout_mapping = {}
    
    if prefs and prefs.day_workout_mapping:
        try:
            day_workout_mapping = json.loads(prefs.day_workout_mapping)
        except:
            day_workout_mapping = {}
    
    if profile.training_days:
        try:
            training_days = json.loads(profile.training_days)
        except:
            training_days = []
    
    if day:
        today_workout_type = day_workout_mapping.get(day, None)
    else:
        today_weekday = checkin_date.weekday()
        day_name = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'][today_weekday]
        today_workout_type = day_workout_mapping.get(day_name, None)

    exercise_goals = {}
    if today_workout_type == 'running':
        distance = profile.current_running_distance_km or profile.baseline_running_distance_km or 5.0
        pace = profile.current_running_pace_min or profile.baseline_running_pace_min or 6.0
        exercise_goals = {
            'distance_km': distance,
            'pace_min_km': pace,
            'estimated_time_min': int(distance * pace)
        }
    elif today_workout_type == 'cycling':
        distance = profile.current_cycling_distance_km or profile.baseline_cycling_distance_km or 15.0
        prefs = current_user.preferences
        time_min = prefs.cycling_avg_time_min if prefs and prefs.cycling_avg_time_min else 60
        speed_kmh = round(distance / (time_min / 60), 1) if time_min > 0 else 20
        exercise_goals = {
            'distance_km': distance,
            'estimated_time_min': time_min,
            'speed_kmh': speed_kmh
        }
    elif today_workout_type == 'swimming':
        distance = profile.current_swimming_distance_m or profile.baseline_swimming_distance_m or 800
        prefs = current_user.preferences
        time_min = prefs.swimming_avg_time_min if prefs and prefs.swimming_avg_time_min else 30
        pace_min_per_100m = round((time_min / distance) * 100, 2) if distance > 0 else 2.0
        exercise_goals = {
            'distance_m': distance,
            'estimated_time_min': time_min,
            'pace_min_per_100m': pace_min_per_100m
        }
    elif today_workout_type == 'walking':
        distance = profile.current_walking_distance_km or profile.baseline_walking_distance_km or 5.0
        exercise_goals = {
            'distance_km': distance
        }
    
    workout_data = None
    if today_workout_type == 'bodyweight':
        workout_data = calculate_workout_data(prefs, profile, today_workout_type, day, daily_log, checkin_date)
    

    day_names_hu = {'monday': 'Hétfő', 'tuesday': 'Kedd', 'wednesday': 'Szerda', 
                    'thursday': 'Csütörtök', 'friday': 'Péntek', 'saturday': 'Szombat', 'sunday': 'Vasárnap'}
    day_names_en = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']
    
    program_days = []
    for i in range(7):
        d = program_start + timedelta(days=i)
        weekday_en = day_names_en[d.weekday()]
        program_days.append({
            'index': i,
            'date': d,
            'short': weekday_en,
            'name': day_names_hu[weekday_en]
        })
    

    current_program_day_idx = None
    for i, pd in enumerate(program_days):
        if pd['short'] == day:
            current_program_day_idx = i
            break
    next_day = None
    next_day_name = None
    is_last_day = False
    
    if current_program_day_idx is not None:
        if current_program_day_idx < 6:
            next_pd = program_days[current_program_day_idx + 1]
            next_day = next_pd['short']
            next_day_name = next_pd['name']
        else:
            is_last_day = True
    
    all_checkins_done = True
    for i in range(7):
        day_date_check = program_start + timedelta(days=i)
        log = DailyLog.query.filter_by(user_id=current_user.id, date=day_date_check).first()
        if not log or not log.completed:
            all_checkins_done = False
            break
    
    if request.method == 'POST':
        if not daily_log:
            daily_log = DailyLog(user_id=current_user.id, date=checkin_date)
            db.session.add(daily_log)
        

        daily_log.exercise_type = today_workout_type
        
        if today_workout_type == 'walking':

            daily_log.steps_completed = int(request.form.get('steps', 0) or 0)
            daily_log.exercise_distance_km = float(request.form.get('exercise_distance_km', 0) or 0)
            daily_log.exercise_time_minutes = int(request.form.get('exercise_time_minutes', 0) or 0)
            daily_log.exercise_intensity = request.form.get('exercise_intensity', 'megfelelő')
            if daily_log.exercise_distance_km and daily_log.exercise_time_minutes:
                daily_log.average_pace_min_km = daily_log.exercise_time_minutes / daily_log.exercise_distance_km
        
        elif today_workout_type == 'running':

            daily_log.exercise_distance_km = float(request.form.get('exercise_distance_km', 0) or 0)
            

            time_min = int(request.form.get('exercise_time_min', 0) or 0)
            time_sec = int(request.form.get('exercise_time_sec', 0) or 0)
            daily_log.exercise_time_minutes = time_min + (time_sec / 60.0)
            
       
            if daily_log.exercise_distance_km and daily_log.exercise_time_minutes:
                daily_log.average_pace_min_km = daily_log.exercise_time_minutes / daily_log.exercise_distance_km
            
 
            daily_log.exercise_intensity = request.form.get('exercise_intensity', 'megfelelő')
            

            if daily_log.exercise_distance_km:
                daily_log.steps_completed = int(daily_log.exercise_distance_km * 1250)
        
        elif today_workout_type == 'cycling':

            daily_log.exercise_distance_km = float(request.form.get('exercise_distance_km', 0) or 0)
            daily_log.exercise_time_minutes = int(request.form.get('exercise_time_minutes', 0) or 0)
            

            if daily_log.exercise_distance_km and daily_log.exercise_time_minutes:
                hours = daily_log.exercise_time_minutes / 60.0
                daily_log.average_speed_kmh = daily_log.exercise_distance_km / hours
            

            daily_log.terrain_type = request.form.get('terrain_type', 'sík')
            daily_log.exercise_intensity = request.form.get('exercise_intensity', 'megfelelő')
            

            if daily_log.exercise_distance_km:
                daily_log.steps_completed = int(daily_log.exercise_distance_km * 100)
        
        elif today_workout_type == 'swimming':

            daily_log.exercise_distance_m = int(request.form.get('exercise_distance_m', 0) or 0)
            daily_log.exercise_time_minutes = int(request.form.get('exercise_time_minutes', 0) or 0)
            

            if daily_log.exercise_distance_m and daily_log.exercise_time_minutes:
                daily_log.average_pace_min_100m = (daily_log.exercise_time_minutes / daily_log.exercise_distance_m) * 100
            

            daily_log.swimming_style = request.form.get('swimming_style', 'gyors')
            daily_log.exercise_intensity = request.form.get('exercise_intensity', 'megfelelő')
            

            daily_log.steps_completed = 500
        
        elif today_workout_type == 'bodyweight':
            daily_log.exercise_intensity = request.form.get('exercise_intensity', 'megfelelő')
            
            performance = {}
            
            for key in request.form:
                if key.startswith('exercise_') and key.endswith('_reps'):
                    input_field = request.form[key]
                    exercise_id_key = key.replace('_reps', '_id')
                    exercise_id = request.form.get(exercise_id_key)
                    
                    if not exercise_id:
                        idx = int(key.split('_')[1])
                        if workout_data and workout_data.get('exercises'):
                            if idx < len(workout_data['exercises']):
                                exercise_name = workout_data['exercises'][idx]['name']
                                import re
                                exercise_id = re.sub(r'[áéíóöőúüű]', lambda m: {
                                    'á':'a','é':'e','í':'i','ó':'o','ö':'o','ő':'o','ú':'u','ü':'u','ű':'u'
                                }[m.group()], exercise_name.lower())
                                exercise_id = exercise_id.replace(' ', '-')
                    
                    if exercise_id and input_field:
                        try:
                            performance[exercise_id] = int(input_field)
                        except ValueError:
                            pass
            
            if not performance and profile.current_bodyweight_reps:
                try:
                    performance = json.loads(profile.current_bodyweight_reps)
                    print(f"  💪 Bodyweight: Nincs form input, használjuk current_reps: {performance}")
                except:
                    pass
            
            if performance:
                daily_log.bodyweight_performance = json.dumps(performance)
            
            daily_log.steps_completed = 2000
        
        else:
            daily_log.steps_completed = int(request.form.get('steps', 0) or 0)
        
        
        daily_log.calories_consumed = int(request.form.get('calories', 0) or 0)
        daily_log.water_ml = int(request.form.get('water', 0) or 0)
        daily_log.notes = request.form.get('notes', '')
        daily_log.completed = request.form.get('completed') == 'on'
        
        day_name = checkin_date.strftime('%A').lower()
        
        work_days = json.loads(profile.work_days_per_week or '[]')
        is_work_day = day_name in work_days
        daily_log.is_work_day = is_work_day
        
        sleep_hours = daily_log.sleep_hours or 7
        daily_steps = daily_log.steps_completed or profile.daily_steps_goal or 5000
        is_training_day = today_workout_type is not None 
        nutrition = calculate_day_nutrition(profile, is_work_day, sleep_hours, None, daily_steps, is_training_day)
        
        daily_log.steps_goal = profile.daily_steps_goal or 5000
        daily_log.calories_goal = nutrition['calories']
        daily_log.water_goal = nutrition['water']
        daily_log.protein_goal = nutrition['protein']
        daily_log.carbs_goal = nutrition['carbs']
        daily_log.fat_goal = nutrition['fat']
        
        db.session.commit()
        
        
        print(f"🔍 PROGRESSZIÓ DEBUG:")
        print(f"  - daily_log.completed: {daily_log.completed}")
        print(f"  - today_workout_type: {today_workout_type}")
        print(f"  - exercise_intensity: {daily_log.exercise_intensity}")
        
        if daily_log.completed and today_workout_type in ['running', 'cycling', 'swimming', 'walking', 'bodyweight']:
            print(f"  ✅ PROGRESSZIÓ FUTTATÁSA...")
            
            adjustment = adjust_goal_after_checkin(profile, daily_log, today_workout_type, prefs)
            
            print(f"  - adjustment: {adjustment}")

            
            if adjustment:
                db.session.commit()
                
                if adjustment.get('change_pct', 0) != 0:
                    flash(f"{adjustment['emoji']} Következő {adjustment['type']} cél módosult: {adjustment['change_pct']:+.0f}% (mai teljesítmény alapján)", 'info')
                    print(f"  FLASH: {adjustment['emoji']} Cél módosult: {adjustment['change_pct']:+.0f}%")
                else:
                    print(f"  Változás: 0% (megfelelő intenzitás)")
            else:
                print(f"Nincs adjustment!")
        else:
            print(f"PROGRESSZIÓ KIHAGYVA (completed={daily_log.completed}, type={today_workout_type})")

        
        if not profile.has_completed_first_checkin:
            profile.has_completed_first_checkin = True
            db.session.commit()
        
        flash('Napi adatok mentve! ✅', 'success')
        return redirect(url_for('workouts.day_view', day=day))
    
    return render_template('workouts/daily_checkin.html',
                         profile=profile,
                         daily_log=daily_log,
                         today=checkin_date,
                         day=day,
                         next_day=next_day,
                         next_day_name=next_day_name,
                         is_last_day=is_last_day,
                         all_checkins_done=all_checkins_done,
                         today_workout_type=today_workout_type,
                         exercise_goals=exercise_goals,
                         workout_data=workout_data)


@bp.route('/day/<day>')
@login_required
def day_view(day):
    from datetime import date, timedelta
    
    profile = current_user.profile
    prefs = current_user.preferences
    
    if not profile:
        flash('Először töltsd ki a profilodat!', 'warning')
        return redirect(url_for('auth.profile_step2'))
    
    if not profile.target_calories:
        profile.calculate_targets()
        db.session.commit()
    
    today = date.today()
    program_start = profile.program_start_date or today
    
    day_names_en = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']
    day_names_hu = {
        'monday': 'Hétfő', 'tuesday': 'Kedd', 'wednesday': 'Szerda',
        'thursday': 'Csütörtök', 'friday': 'Péntek', 'saturday': 'Szombat', 'sunday': 'Vasárnap'
    }
    
    program_day_map = {}
    for i in range(7):
        d = program_start + timedelta(days=i)
        d_weekday = d.weekday()
        d_name = day_names_en[d_weekday]
        program_day_map[d_name] = d
    
    day_date = program_day_map.get(day, program_start)
    
    training_days = []
    day_workout_mapping = {}
    
    if profile.training_days:
        try:
            training_days = json.loads(profile.training_days)
        except:
            training_days = []
    
    if prefs and prefs.day_workout_mapping:
        try:
            day_workout_mapping = json.loads(prefs.day_workout_mapping)
        except:
            day_workout_mapping = {}

    today_workout_type = day_workout_mapping.get(day, None) 
    
    is_training_day = today_workout_type is not None

    work_days = []
    if profile.work_days_per_week:
        try:
            work_days = json.loads(profile.work_days_per_week)
        except:
            work_days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday']
    else:
        work_days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday']
    
    is_work_day = day in work_days
    work_start = profile.work_start_time or '08:00'
    work_end = profile.work_end_time or '17:00'
    workout_pref = profile.workout_time_preference or 'flexible'
    

    daily_log = DailyLog.query.filter_by(
        user_id=current_user.id,
        date=day_date
    ).first()
    
    if daily_log and not daily_log.completed and is_training_day:
        needs_save = False
        
        if today_workout_type == 'running' and not daily_log.target_running_distance_km:
            daily_log.target_running_distance_km = profile.current_running_distance_km
            needs_save = True
        
        elif today_workout_type == 'cycling' and not daily_log.target_cycling_distance_km:
            daily_log.target_cycling_distance_km = profile.current_cycling_distance_km
            needs_save = True
        
        elif today_workout_type == 'swimming' and not daily_log.target_swimming_distance_m:
            daily_log.target_swimming_distance_m = profile.current_swimming_distance_m
            needs_save = True
        
        elif today_workout_type == 'walking' and not daily_log.target_walking_distance_km:
            daily_log.target_walking_distance_km = profile.current_walking_distance_km
            needs_save = True
        
        elif today_workout_type == 'bodyweight' and not daily_log.target_bodyweight_reps:
            daily_log.target_bodyweight_reps = profile.current_bodyweight_reps
            needs_save = True
        
        if needs_save:
            db.session.commit()
    
    day_weight = None
    sleep_hours = 7
    
    if daily_log:
        day_weight = daily_log.weight_kg
        sleep_hours = daily_log.sleep_hours or 7
    
    if not day_weight:
        day_weight = profile.current_weight_kg or profile.starting_weight_kg

    daily_steps = daily_log.steps_completed if daily_log else (profile.daily_steps_goal or 5000)
    day_nutrition = calculate_day_nutrition(profile, is_work_day, sleep_hours, day_weight, daily_steps, is_training_day)

    workout_data = None
    workout_calories_burned = 0
    
    if is_training_day and today_workout_type:
        workout_data = calculate_workout_data(prefs, profile, today_workout_type, day, daily_log, day_date)
        workout_calories_burned = workout_data.get('calories_burned', 0)
        

        extra_cals = int(workout_calories_burned * 0.5)
        day_nutrition['calories'] += extra_cals
        day_nutrition['water'] += 500
        

        new_cals = day_nutrition['calories']
        goal = (profile.goal or '').lower()

        if goal in ['izomépítés', 'hízás']:
            fat_percent = 0.25
        elif goal == 'fogyás':
            fat_percent = 0.25
        else:
            fat_percent = 0.28
        
        day_nutrition['fat'] = int(new_cals * fat_percent / 9)
        protein_cal = day_nutrition['protein'] * 4
        fat_cal = day_nutrition['fat'] * 9
        remaining_cal = new_cals - protein_cal - fat_cal
        day_nutrition['carbs'] = max(80, int(remaining_cal / 4))
    
    target_cals = day_nutrition['calories']
    target_protein = day_nutrition['protein']
    target_carbs = day_nutrition['carbs']
    target_fat = day_nutrition['fat']
    target_water = day_nutrition['water']
    

    if is_training_day and today_workout_type == 'walking':
        day_steps = profile.daily_steps_goal or 5000
    else:

        day_steps = 5000
    

    wake_time = profile.wake_time or '07:00'
    bed_time = profile.bed_time or '22:00'
    
    daily_meals = 4
    if daily_log and daily_log.meals_count:
        daily_meals = daily_log.meals_count
    
    meals = get_meals_schedule(target_cals, daily_meals, wake_time, target_protein)
    

    water_schedule = get_water_schedule(target_water, is_training_day, today_workout_type)
    
    days_data = []
    for i in range(7):
        d_date = program_start + timedelta(days=i)
        d_weekday = d_date.weekday()
        d_name_en = day_names_en[d_weekday]
        d_name_hu = day_names_hu[d_name_en]
        
        d_log = DailyLog.query.filter_by(user_id=current_user.id, date=d_date).first()
        d_workout = day_workout_mapping.get(d_name_en, None)
        
        days_data.append({
            'short': d_name_en,
            'name': d_name_hu,
            'date': d_date,
            'is_training': d_name_en in training_days,
            'workout_type': d_workout,
            'completed': d_log.completed if d_log else False,
            'is_today': d_date == today,
            'is_current': d_name_en == day
        })
    
    checkin_completed = daily_log and daily_log.completed
    needs_daily_input = not daily_log or daily_log.weight_kg is None or daily_log.sleep_hours is None
    
    program_day_index = (day_date - program_start).days
    is_last_day = program_day_index >= 6 
    
    
    next_day = None
    next_day_name = None
    
    if checkin_completed and not is_last_day:
        next_day_date = day_date + timedelta(days=1)
        next_day_weekday = next_day_date.weekday()
        next_day = day_names_en[next_day_weekday]
        next_day_name = day_names_hu[next_day]
        print(f"  ✅ Következő nap: {next_day} ({next_day_name})")
    else:
        print(f"  ❌ Nincs következő nap")
        print(f"     - checkin_completed: {checkin_completed}")
        print(f"     - not is_last_day: {not is_last_day}")
    
    show_weekly_summary = False
    if is_last_day and checkin_completed:
        print(f"  🏆 Utolsó nap - ellenőrzés...")
        all_complete = True
        for i in range(7):
            check_date = program_start + timedelta(days=i)
            check_log = DailyLog.query.filter_by(user_id=current_user.id, date=check_date).first()
            is_done = check_log.completed if check_log else False
            print(f"     {check_date} ({check_date.strftime('%A')}): {is_done}")
            if not check_log or not check_log.completed:
                all_complete = False
        print(f"  all_complete: {all_complete}")
        show_weekly_summary = all_complete
    
    print(f"  VÉGEREDMÉNY:")
    print(f"    next_day: {next_day}")
    print(f"    show_weekly_summary: {show_weekly_summary}\n")
    

    day_info = {
        'name': day_names_hu[day],
        'date': day_date,
        'is_training': is_training_day,
        'workout_type': today_workout_type,
        'is_work_day': is_work_day
    }
    

    from app.forms import EmptyForm
    form = EmptyForm()
    
    return render_template('workouts/day_view.html',
                         form=form,
                         profile=profile,
                         prefs=prefs,
                         preferences=prefs,
                         day=day,
                         day_info=day_info,
                         day_steps=day_steps,
                         workout_data=workout_data,
                         workout_calories_burned=workout_calories_burned,
                         meals=meals,
                         target_cals=target_cals,
                         target_protein=target_protein,
                         target_carbs=target_carbs,
                         target_fat=target_fat,
                         day_nutrition=day_nutrition,
                         water_schedule=water_schedule,
                         target_water=target_water,
                         days_data=days_data,
                         is_work_day=is_work_day,
                         is_training_day=is_training_day,
                         today_workout_type=today_workout_type,
                         checkin_completed=checkin_completed,
                         daily_log=daily_log,
                         day_date=day_date,
                         needs_daily_input=needs_daily_input,
                         next_day=next_day,
                         next_day_name=next_day_name,
                         is_last_day=is_last_day,
                         show_weekly_summary=show_weekly_summary,
                         day_weight=day_weight)


def calculate_workout_data(prefs, profile, workout_type, day, daily_log=None, day_date=None):

    weight = profile.current_weight_kg or 70
    data = {
        'type': workout_type,
        'calories_burned': 0,
        'distance': 0,
        'duration': 0,
        'pace': None,
        'level': 'beginner',
        'exercises': []
    }
    
    level_convert = {'kezdő': 'beginner', 'közép': 'intermediate', 'haladó': 'advanced'}
    
    if workout_type == 'walking':       
        if daily_log and daily_log.target_walking_distance_km:

            distance_km = daily_log.target_walking_distance_km
        else:

            distance_km = profile.current_walking_distance_km or profile.baseline_walking_distance_km or 5.0
        
        duration = int(distance_km * 12)  
        speed_kmh = 5.0 
        
        if speed_kmh < 4.0:
            met = 2.5
        elif speed_kmh < 5.6:
            met = 3.5
        else:
            met = 4.5
        
        data['distance'] = round(distance_km, 1)
        data['duration'] = duration
        data['speed_kmh'] = round(speed_kmh, 1)
        data['met'] = met
        data['calories_burned'] = int(met * weight * (duration / 60))
        
    elif workout_type == 'running':
        pace_min = prefs.running_pace_min or 5 if prefs else 5
        pace_sec = prefs.running_pace_sec or 30 if prefs else 30
        avg_km = prefs.running_avg_distance_km or 5.0 if prefs else 5.0
        
        if daily_log and daily_log.target_running_distance_km:
            km = daily_log.target_running_distance_km
        else:
            km = profile.current_running_distance_km or profile.baseline_running_distance_km or avg_km
        
        pace_total_sec = (pace_min * 60) + pace_sec
        duration = int((km * pace_total_sec) / 60)
        

        if duration > 0:
            hours = duration / 60.0
            speed_kmh = km / hours
        else:
            speed_kmh = 10.0
        
        if speed_kmh < 8.0:
            met = 8.0 
        elif speed_kmh < 9.8:
            met = 9.0
        elif speed_kmh < 11.0:
            met = 10.5
        else:
            met = 12.5
        
        data['distance'] = round(km, 1)
        data['duration'] = duration
        data['pace'] = f"{pace_min}:{pace_sec:02d}"
        data['speed_kmh'] = round(speed_kmh, 1)
        data['met'] = met
        data['calories_burned'] = int(met * weight * (duration / 60))
        
    elif workout_type == 'cycling':
        avg_km = prefs.cycling_avg_distance_km or 20.0 if prefs else 20.0
        
        if daily_log and daily_log.target_cycling_distance_km:
            avg_km = daily_log.target_cycling_distance_km
        else:
            avg_km = profile.current_cycling_distance_km or profile.baseline_cycling_distance_km or avg_km
        
        duration = prefs.cycling_avg_time_min if prefs and prefs.cycling_avg_time_min else 60

        speed = round(avg_km / (duration / 60), 1) if duration > 0 else 20
        
        if speed < 16:
            met = 4.0
        elif speed < 19:
            met = 6.0
        elif speed < 22:
            met = 8.0
        else:
            met = 10.0
        
        data['distance'] = avg_km
        data['duration'] = duration
        data['speed'] = speed
        data['met'] = met
        data['calories_burned'] = int(met * weight * (duration / 60))
        
    elif workout_type == 'swimming':
        avg_m = prefs.swimming_avg_distance_m or 1000 if prefs else 1000
        

        if daily_log and daily_log.target_swimming_distance_m:
            avg_m = daily_log.target_swimming_distance_m
        else:
            avg_m = profile.current_swimming_distance_m or profile.baseline_swimming_distance_m or avg_m
        

        duration = prefs.swimming_avg_time_min if prefs and prefs.swimming_avg_time_min else 30
        

        if duration > 0 and avg_m > 0:
            pace_min_per_100m = (duration / avg_m) * 100
        else:
            pace_min_per_100m = 2.0
        

        if pace_min_per_100m > 3.0:
            met = 6.0
        elif pace_min_per_100m > 2.5:
            met = 8.0
        elif pace_min_per_100m > 2.0:
            met = 9.5
        else:
            met = 11.0
        
        data['distance'] = avg_m
        data['duration'] = duration
        data['pace_min_per_100m'] = round(pace_min_per_100m, 2)
        data['met'] = met
        data['calories_burned'] = int(met * weight * (duration / 60))
        
    elif workout_type == 'bodyweight':

        data['duration'] = 40
        

        data['exercises'] = get_bodyweight_exercises(day, prefs, profile, daily_log)
        

        baseline_total = 0
        current_total = 0
        
        if profile and profile.baseline_bodyweight_reps:
            try:
                baseline = json.loads(profile.baseline_bodyweight_reps)
                

                if daily_log and daily_log.target_bodyweight_reps:
                    current = json.loads(daily_log.target_bodyweight_reps)
                else:
                    current = json.loads(profile.current_bodyweight_reps) if profile.current_bodyweight_reps else baseline
                
                for key in baseline:
                    baseline_total += baseline.get(key, 0)
                    current_total += current.get(key, 0)
            except:
                pass
        
        if baseline_total == 0:
            baseline_total = 10 + 8 + 10 + 15 + 10 + 15 + 12 + 30 + 15 + 8 
        if current_total == 0:
            current_total = baseline_total
        
        ratio = current_total / baseline_total if baseline_total > 0 else 1.0
        
        met_min = 4.0
        met_max = 8.0
        met = met_min + (met_max - met_min) * min(ratio, 2.0) / 2.0
        
        data['calories_burned'] = int(met * weight * (data['duration'] / 60))
    
    return data


def get_bodyweight_exercises(day, prefs, profile, daily_log=None):
    training_days = []
    if prefs and prefs.day_workout_mapping:
        try:
            mapping = json.loads(prefs.day_workout_mapping)
            training_days = [d for d, t in mapping.items() if t == 'bodyweight']
        except:
            pass
    
    num_days = len(training_days)
    day_index = training_days.index(day) if day in training_days else 0
    
    if num_days <= 2:
        focus = 'upper' if day_index % 2 == 0 else 'lower'
    elif num_days == 3:
        focuses = ['upper', 'lower', 'full']
        focus = focuses[day_index % 3]
    else:
        focuses = ['push', 'pull', 'legs', 'core']
        focus = focuses[day_index % 4]
    
    current_reps = {}
    if profile:
        try:
            if daily_log and daily_log.target_bodyweight_reps:
                current_reps = json.loads(daily_log.target_bodyweight_reps)
            else:
                current_reps = json.loads(profile.current_bodyweight_reps) if profile.current_bodyweight_reps else {}
        except:
            pass
    
    if not current_reps:
        current_reps = {
            'fekvotamasz': 10,
            'pike-push-up': 8,
            'tricepsz-nyomas': 10,
            'guggolas': 15,
            'kitores': 10,
            'glute-bridge': 15,
            'superman': 12,
            'plank': 30,
            'mountain-climbers': 15,
            'burpee': 8
        }
    
    sets = 3
    exercises = []
    
    if focus in ['upper', 'push']:
        exercises = [
            {'name': 'Fekvőtámasz', 'sets': sets, 'reps': str(current_reps.get('fekvotamasz', 10)),
             'video': 'https://www.youtube.com/watch?v=IODxDxX7oi4',
             'tip': 'Tartsd a tested egyenesen!'},
            {'name': 'Pike Push-up', 'sets': sets, 'reps': str(current_reps.get('pike-push-up', 8)),
             'video': 'https://www.youtube.com/watch?v=x4YNi4nRboU',
             'tip': 'Váll edzés - csípő magasan'},
            {'name': 'Tricepsz nyomás', 'sets': sets, 'reps': str(current_reps.get('tricepsz-nyomas', 10)),
             'video': 'https://www.youtube.com/watch?v=6kALZikXxLc',
             'tip': 'Könyök a test mellett'},
        ]
    elif focus in ['lower', 'legs']:
        exercises = [
            {'name': 'Guggolás', 'sets': sets, 'reps': str(current_reps.get('guggolas', 15)),
             'video': 'https://www.youtube.com/watch?v=aclHkVaku9U',
             'tip': 'Térd ne menjen a lábujjak elé'},
            {'name': 'Kitörés', 'sets': sets, 'reps': f"{current_reps.get('kitores', 10)}/láb",
             'video': 'https://www.youtube.com/watch?v=QOVaHwm-Q6U',
             'tip': 'Egyensúly és kontroll'},
            {'name': 'Glute Bridge', 'sets': sets, 'reps': str(current_reps.get('glute-bridge', 15)),
             'video': 'https://www.youtube.com/watch?v=8bbE64NuDTU',
             'tip': 'Szorítsd a farizmod!'},
        ]
    elif focus == 'pull':
        exercises = [
            {'name': 'Superman', 'sets': sets, 'reps': str(current_reps.get('superman', 12)),
             'video': 'https://www.youtube.com/watch?v=cc6UVRS7PW4',
             'tip': 'Hát erősítés'},
            {'name': 'Reverse Snow Angels', 'sets': sets, 'reps': str(current_reps.get('reverse-snow-angels', 10)),
             'video': 'https://www.youtube.com/watch?v=0t4GpCBqOR8',
             'tip': 'Lapocka összehúzás'},
            {'name': 'Prone Y Raises', 'sets': sets, 'reps': str(current_reps.get('prone-y-raises', 10)),
             'video': 'https://www.youtube.com/watch?v=B6fE1RY_5Mg',
             'tip': 'Váll stabilizálás'},
        ]
    elif focus in ['full', 'core']:
        exercises = [
            {'name': 'Plank', 'sets': sets, 'reps': f"{current_reps.get('plank', 30)} mp",
             'video': 'https://www.youtube.com/watch?v=pSHjTRCQxIw',
             'tip': 'Egyenes test, szorított core'},
            {'name': 'Mountain climbers', 'sets': sets, 'reps': str(current_reps.get('mountain-climbers', 15)),
             'video': 'https://www.youtube.com/watch?v=nmwgirgXLYM',
             'tip': 'Gyors, kontrollált mozgás'},
            {'name': 'Burpee', 'sets': sets, 'reps': str(current_reps.get('burpee', 8)),
             'video': 'https://www.youtube.com/watch?v=JZQA08SlJnM',
             'tip': 'Teljes test gyakorlat'},
        ]
    
    return exercises



def get_meals_schedule(target_cals, daily_meals, wake_time, target_protein):
    meals = {}
    
    if daily_meals <= 3:
        meals = {
            'breakfast': {'name': 'Reggeli', 'icon': '🌅', 'percent': 0.30, 'time': wake_time},
            'lunch': {'name': 'Ebéd', 'icon': '☀️', 'percent': 0.40, 'time': '12:30'},
            'dinner': {'name': 'Vacsora', 'icon': '🌙', 'percent': 0.30, 'time': '19:00'}
        }
    elif daily_meals == 4:
        meals = {
            'breakfast': {'name': 'Reggeli', 'icon': '🌅', 'percent': 0.25, 'time': wake_time},
            'lunch': {'name': 'Ebéd', 'icon': '☀️', 'percent': 0.35, 'time': '12:30'},
            'snack': {'name': 'Uzsonna', 'icon': '🥜', 'percent': 0.15, 'time': '16:00'},
            'dinner': {'name': 'Vacsora', 'icon': '🌙', 'percent': 0.25, 'time': '19:00'}
        }
    elif daily_meals == 5:
        meals = {
            'breakfast': {'name': 'Reggeli', 'icon': '🌅', 'percent': 0.20, 'time': wake_time},
            'snack1': {'name': 'Tízórai', 'icon': '🍎', 'percent': 0.10, 'time': '10:00'},
            'lunch': {'name': 'Ebéd', 'icon': '☀️', 'percent': 0.30, 'time': '12:30'},
            'snack2': {'name': 'Uzsonna', 'icon': '🥜', 'percent': 0.15, 'time': '16:00'},
            'dinner': {'name': 'Vacsora', 'icon': '🌙', 'percent': 0.25, 'time': '19:00'}
        }
    else:
        meals = {
            'breakfast': {'name': 'Reggeli', 'icon': '🌅', 'percent': 0.18, 'time': wake_time},
            'snack1': {'name': 'Tízórai', 'icon': '🍎', 'percent': 0.10, 'time': '10:00'},
            'lunch': {'name': 'Ebéd', 'icon': '☀️', 'percent': 0.25, 'time': '12:30'},
            'snack2': {'name': 'Uzsonna', 'icon': '🥜', 'percent': 0.12, 'time': '16:00'},
            'dinner': {'name': 'Vacsora', 'icon': '🌙', 'percent': 0.20, 'time': '19:00'},
            'snack3': {'name': 'Esti snack', 'icon': '🥛', 'percent': 0.15, 'time': '21:00'}
        }
    
    for meal_key, meal in meals.items():
        meal['calories'] = int(target_cals * meal['percent'])
        meal['recipes'] = get_recipe_recommendations(meal_key, meal['calories'], target_protein=target_protein, limit=3)
    
    return meals


def get_water_schedule(target_water, is_training_day, workout_type):
    per_time = target_water // 3 
    
    schedule = [
        {'time': 'Reggel', 'amount': per_time, 'tip': '🌅'},
        {'time': 'Délután', 'amount': per_time, 'tip': '☀️'},
        {'time': 'Este', 'amount': per_time, 'tip': '🌙'},
    ]
    
    return schedule


@bp.route('/walking/<day>')
@login_required
def walking_day(day):
    from datetime import date, timedelta
    
    profile = current_user.profile
    
    if not profile:
        flash('Először töltsd ki a profilodat!', 'warning')
        return redirect(url_for('auth.profile_step2'))
    
    if not profile.target_calories:
        profile.calculate_targets()
        db.session.commit()
    
    program_start = profile.program_start_date or date.today()
    today = date.today()
    

    days_data = {
        'monday': {'name': 'Hétfő', 'multiplier': 1.0, 'type': 'normal', 'index': 0},
        'tuesday': {'name': 'Kedd', 'multiplier': 0.9, 'type': 'light', 'index': 1},
        'wednesday': {'name': 'Szerda', 'multiplier': 1.0, 'type': 'normal', 'index': 2},
        'thursday': {'name': 'Csütörtök', 'multiplier': 0.9, 'type': 'light', 'index': 3},
        'friday': {'name': 'Péntek', 'multiplier': 1.0, 'type': 'normal', 'index': 4},
        'saturday': {'name': 'Szombat', 'multiplier': 1.2, 'type': 'long', 'index': 5},
        'sunday': {'name': 'Vasárnap', 'multiplier': 0.8, 'type': 'rest', 'index': 6}
    }
    
    if day not in days_data:
        flash('Érvénytelen nap!', 'error')
        return redirect(url_for('workouts.index'))
    
    day_info = days_data[day]
    
    day_map = {
        'monday': 0, 'tuesday': 1, 'wednesday': 2, 'thursday': 3,
        'friday': 4, 'saturday': 5, 'sunday': 6
    }
    target_weekday = day_map.get(day, 0)
    
    day_date = None
    for i in range(7):
        check_date = program_start + timedelta(days=i)
        if check_date.weekday() == target_weekday:
            day_date = check_date
            break
    
    if day_date is None:
        day_date = today
    
    day_program_index = (day_date - program_start).days
    
    if day_program_index > 0:
        prev_day_date = program_start + timedelta(days=day_program_index - 1)
        prev_log = DailyLog.query.filter_by(user_id=current_user.id, date=prev_day_date).first()
        
        if not prev_log or not prev_log.completed:
            flash('Ez a nap még nem elérhető! Először fejezd be az előző napot.', 'warning')
            return redirect(url_for('workouts.index'))
    
    work_days = []
    if profile.work_days_per_week:
        try:
            work_days = json.loads(profile.work_days_per_week)
        except:
            work_days = []
    
    is_work_day = day in work_days
    day_info['is_work_day'] = is_work_day
    
    work_start = profile.work_start_time or '08:00'
    work_end = profile.work_end_time or '17:00'
    workout_pref = profile.workout_time_preference or 'flexible'
    
    base_distance_km = profile.current_walking_distance_km or profile.baseline_walking_distance_km or 5.0
    
    if not is_work_day:
        day_info['type'] = 'free'
        day_info['multiplier'] = 1.1 
    
    day_distance = round(base_distance_km * day_info['multiplier'], 1)
    day_km = day_distance
    day_calories_burned = int(day_distance * 50)
    
    daily_log = DailyLog.query.filter_by(
        user_id=current_user.id,
        date=day_date
    ).first()
    
    sleep_hours = daily_log.sleep_hours if daily_log else None
    
    day_weight = None
    if daily_log and daily_log.weight_kg:
        day_weight = daily_log.weight_kg
    
    daily_steps = daily_log.steps_completed if daily_log else (profile.daily_steps_goal or 5000)
    is_training_day = True 
    day_nutrition = calculate_day_nutrition(profile, is_work_day, sleep_hours, day_weight, daily_steps, is_training_day)
    
    target_cals = day_nutrition['calories']
    target_protein = day_nutrition['protein']
    target_carbs = day_nutrition['carbs']
    target_fat = day_nutrition['fat']
    target_water = day_nutrition['water']
    
    wake_time = profile.wake_time or '07:00'
    bed_time = profile.bed_time or '22:00'
    
    daily_meals = 4
    if daily_log and daily_log.meals_count:
        daily_meals = daily_log.meals_count
    
    meals = {}
    
    if daily_meals <= 3:
        meals = {
            'breakfast': {'name': 'Reggeli', 'icon': '🌅', 'percent': 0.30, 'time': wake_time},
            'lunch': {'name': 'Ebéd', 'icon': '☀️', 'percent': 0.40, 'time': '12:30'},
            'dinner': {'name': 'Vacsora', 'icon': '🌙', 'percent': 0.30, 'time': '19:00'}
        }
    elif daily_meals == 4:
        meals = {
            'breakfast': {'name': 'Reggeli', 'icon': '🌅', 'percent': 0.25, 'time': wake_time},
            'lunch': {'name': 'Ebéd', 'icon': '☀️', 'percent': 0.35, 'time': '12:30'},
            'snack': {'name': 'Uzsonna', 'icon': '🥜', 'percent': 0.15, 'time': '16:00'},
            'dinner': {'name': 'Vacsora', 'icon': '🌙', 'percent': 0.25, 'time': '19:00'}
        }
    elif daily_meals == 5:
        meals = {
            'breakfast': {'name': 'Reggeli', 'icon': '🌅', 'percent': 0.20, 'time': wake_time},
            'snack1': {'name': 'Tízórai', 'icon': '🍎', 'percent': 0.10, 'time': '10:00'},
            'lunch': {'name': 'Ebéd', 'icon': '☀️', 'percent': 0.30, 'time': '12:30'},
            'snack2': {'name': 'Uzsonna', 'icon': '🥜', 'percent': 0.15, 'time': '16:00'},
            'dinner': {'name': 'Vacsora', 'icon': '🌙', 'percent': 0.25, 'time': '19:00'}
        }
    else:
        meals = {
            'breakfast': {'name': 'Reggeli', 'icon': '🌅', 'percent': 0.18, 'time': wake_time},
            'snack1': {'name': 'Tízórai', 'icon': '🍎', 'percent': 0.10, 'time': '10:00'},
            'lunch': {'name': 'Ebéd', 'icon': '☀️', 'percent': 0.25, 'time': '12:30'},
            'snack2': {'name': 'Uzsonna', 'icon': '🥜', 'percent': 0.12, 'time': '16:00'},
            'dinner': {'name': 'Vacsora', 'icon': '🌙', 'percent': 0.20, 'time': '19:00'},
            'snack3': {'name': 'Esti snack', 'icon': '🥛', 'percent': 0.15, 'time': '21:00'}
        }
    
    for meal_key, meal in meals.items():
        meal['calories'] = int(target_cals * meal['percent'])
        meal['recipes'] = get_recipe_recommendations(
            meal_key, 
            meal['calories'], 
            target_protein=target_protein,
            limit=3
        )
    water_per_glass = 250
    total_glasses = int(target_water / water_per_glass)
    
    water_schedule = [
        {'time': 'Ébredés után', 'amount': water_per_glass, 'tip': 'Indítsd a napot egy pohár vízzel!'},
        {'time': 'Reggeli előtt', 'amount': water_per_glass, 'tip': 'Segíti az emésztést'},
        {'time': 'Délelőtt', 'amount': water_per_glass * 2, 'tip': 'Munka közben rendszeresen igyál'},
        {'time': 'Ebéd előtt', 'amount': water_per_glass, 'tip': 'Csökkenti az étvágyat'},
        {'time': 'Délután', 'amount': water_per_glass * 2, 'tip': 'Tartsd fenn az energiaszintet'},
        {'time': 'Edzés/séta közben', 'amount': int(water_per_glass * 1.2), 'tip': 'Pótold a folyadékveszteséget'},
        {'time': 'Vacsora előtt', 'amount': water_per_glass, 'tip': 'Segíti az emésztést'},
        {'time': 'Este', 'amount': int(water_per_glass * 0.8), 'tip': 'Ne túl sokat lefekvés előtt'}
    ]
    
    walk_schedule = []
    work_start_hour = int(work_start.split(':')[0])
    work_end_hour = int(work_end.split(':')[0])
    
    if is_work_day:
        if workout_pref == 'before_work':
            walk_schedule = [
                {'time': f'Reggel ({work_start_hour-1}:00)', 'distance': round(day_distance * 0.4, 1), 'duration': int(day_distance * 0.4 * 12), 
                 'intensity': 'közepes-intenzív', 'tip': '🔥 FŐ SÉTA - Munka előtt, frissítő reggeli edzés!', 'main': True},
                {'time': 'Ebédszünet', 'distance': round(day_distance * 0.2, 1), 'duration': int(day_distance * 0.2 * 12), 
                 'intensity': 'könnyű', 'tip': 'Rövid séta ebéd után'},
                {'time': f'Munka után ({work_end})', 'distance': round(day_distance * 0.25, 1), 'duration': int(day_distance * 0.25 * 12), 
                 'intensity': 'könnyű', 'tip': 'Lazító séta hazafelé'},
                {'time': 'Este', 'distance': round(day_distance * 0.15, 1), 'duration': int(day_distance * 0.15 * 12), 
                 'intensity': 'könnyű', 'tip': 'Esti séta vacsora után'}
            ]
        elif workout_pref == 'after_work':
            walk_schedule = [
                {'time': 'Reggel', 'distance': round(day_distance * 0.15, 1), 'duration': int(day_distance * 0.15 * 12), 
                 'intensity': 'könnyű', 'tip': 'Rövid reggeli séta'},
                {'time': 'Ebédszünet', 'distance': round(day_distance * 0.2, 1), 'duration': int(day_distance * 0.2 * 12), 
                 'intensity': 'könnyű', 'tip': 'Séta ebéd után'},
                {'time': f'Munka után ({work_end})', 'distance': round(day_distance * 0.45, 1), 'duration': int(day_distance * 0.45 * 12), 
                 'intensity': 'közepes-intenzív', 'tip': '🔥 FŐ SÉTA - Munka után, stresszoldó edzés!', 'main': True},
                {'time': 'Este', 'distance': round(day_distance * 0.2, 1), 'duration': int(day_distance * 0.2 * 12), 
                 'intensity': 'könnyű', 'tip': 'Könnyű esti séta'}
            ]
        elif workout_pref == 'lunch_break':
            walk_schedule = [
                {'time': 'Reggel', 'distance': round(day_distance * 0.2, 1), 'duration': int(day_distance * 0.2 * 12), 
                 'intensity': 'könnyű', 'tip': 'Reggeli bemelegítés'},
                {'time': 'Ebédszünet (12:00-13:00)', 'distance': round(day_distance * 0.35, 1), 'duration': int(day_distance * 0.35 * 12), 
                 'intensity': 'közepes', 'tip': '🔥 FŐ SÉTA - Ebédszünetben, energizáló!', 'main': True},
                {'time': f'Munka után ({work_end})', 'distance': round(day_distance * 0.25, 1), 'duration': int(day_distance * 0.25 * 12), 
                 'intensity': 'könnyű', 'tip': 'Séta hazafelé'},
                {'time': 'Este', 'distance': round(day_distance * 0.2, 1), 'duration': int(day_distance * 0.2 * 12), 
                 'intensity': 'könnyű', 'tip': 'Esti séta'}
            ]
        else: 
            walk_schedule = [
                {'time': 'Reggel', 'distance': round(day_distance * 0.2, 1), 'duration': int(day_distance * 0.2 * 12), 
                 'intensity': 'közepes', 'tip': 'Reggeli séta'},
                {'time': 'Délelőtt', 'distance': round(day_distance * 0.2, 1), 'duration': int(day_distance * 0.2 * 12), 
                 'intensity': 'könnyű', 'tip': 'Irodai szünetek, lépcsőzés'},
                {'time': 'Ebéd után', 'distance': round(day_distance * 0.2, 1), 'duration': int(day_distance * 0.2 * 12), 
                 'intensity': 'könnyű', 'tip': 'Emésztést segítő séta'},
                {'time': 'Délután', 'distance': round(day_distance * 0.2, 1), 'duration': int(day_distance * 0.2 * 12), 
                 'intensity': 'közepes', 'tip': 'Délutáni séta'},
                {'time': 'Este', 'distance': round(day_distance * 0.2, 1), 'duration': int(day_distance * 0.2 * 12), 
                 'intensity': 'könnyű', 'tip': 'Esti lazító séta'}
            ]
    else:
        if day_info['type'] == 'rest' or day == 'sunday':
            walk_schedule = [
                {'time': 'Reggel (amikor felkelsz)', 'distance': round(day_distance * 0.3, 1), 'duration': int(day_distance * 0.3 * 12), 
                 'intensity': 'könnyű', 'tip': '😴 Pihenőnap - laza reggeli séta'},
                {'time': 'Délután', 'distance': round(day_distance * 0.4, 1), 'duration': int(day_distance * 0.4 * 12), 
                 'intensity': 'könnyű', 'tip': 'Nyugodt séta, regeneráció'},
                {'time': 'Este', 'distance': round(day_distance * 0.3, 1), 'duration': int(day_distance * 0.3 * 12), 
                 'intensity': 'könnyű', 'tip': 'Esti séta vacsora után'}
            ]
        else:
            walk_schedule = [
                {'time': 'Reggel', 'distance': round(day_distance * 0.2, 1), 'duration': int(day_distance * 0.2 * 12), 
                 'intensity': 'közepes', 'tip': 'Ébredés utáni séta'},
                {'time': 'Délelőtt', 'distance': round(day_distance * 0.35, 1), 'duration': int(day_distance * 0.35 * 12), 
                 'intensity': 'közepes-intenzív', 'tip': '🔥 FŐ SÉTA - Szabadnap, élvezd a hosszabb sétát!', 'main': True},
                {'time': 'Délután', 'distance': round(day_distance * 0.25, 1), 'duration': int(day_distance * 0.25 * 12), 
                 'intensity': 'könnyű', 'tip': 'Délutáni séta'},
                {'time': 'Este', 'distance': round(day_distance * 0.2, 1), 'duration': int(day_distance * 0.2 * 12), 
                 'intensity': 'könnyű', 'tip': 'Esti lazító séta'}
            ]
    
    daily_log = DailyLog.query.filter_by(
        user_id=current_user.id,
        date=day_date
    ).first()
    
    checkin_completed = daily_log and daily_log.completed
    
    needs_daily_input = False
    if not daily_log:
        needs_daily_input = True
    elif daily_log.weight_kg is None or daily_log.sleep_hours is None:
        needs_daily_input = True
    
    day_names_en = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']
    day_names_hu = {'monday': 'Hétfő', 'tuesday': 'Kedd', 'wednesday': 'Szerda', 
                    'thursday': 'Csütörtök', 'friday': 'Péntek', 'saturday': 'Szombat', 'sunday': 'Vasárnap'}
    
    program_days = []
    for i in range(7):
        d = program_start + timedelta(days=i)
        weekday_en = day_names_en[d.weekday()]
        program_days.append({
            'index': i,
            'date': d,
            'short': weekday_en,
            'name': day_names_hu[weekday_en]
        })
    
    current_program_day_idx = day_program_index
    
    next_day = None
    next_day_name = None
    is_last_day = False
    
    if current_program_day_idx < 6:
        next_pd = program_days[current_program_day_idx + 1]
        next_day = next_pd['short']
        next_day_name = next_pd['name']
    else:
        is_last_day = True
    
    return render_template('workouts/walking_day.html',
                         profile=profile,
                         day=day,
                         day_info=day_info,
                         day_distance=day_distance,
                         day_km=day_km,
                         day_calories_burned=day_calories_burned,
                         meals=meals,
                         target_cals=target_cals,
                         target_protein=target_protein,
                         target_carbs=target_carbs,
                         target_fat=target_fat,
                         day_nutrition=day_nutrition,
                         water_schedule=water_schedule,
                         target_water=target_water,
                         walk_schedule=walk_schedule,
                         days_data=days_data,
                         is_work_day=is_work_day,
                         work_start=work_start,
                         work_end=work_end,
                         workout_pref=workout_pref,
                         checkin_completed=checkin_completed,
                         daily_log=daily_log,
                         day_date=day_date,
                         needs_daily_input=needs_daily_input,
                         daily_meals=daily_meals,
                         next_day=next_day,
                         next_day_name=next_day_name,
                         is_last_day=is_last_day,
                         day_weight=day_weight)


@bp.route('/running/<day>')
@login_required
def running_day(day):
    from datetime import date, timedelta
    
    profile = current_user.profile
    prefs = current_user.preferences
    
    if not profile:
        return redirect(url_for('auth.profile_step2'))
    
 
    today = date.today()
    program_start = profile.program_start_date or today
    

    day_names_en = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']
    day_names_hu = {'monday': 'Hétfő', 'tuesday': 'Kedd', 'wednesday': 'Szerda', 
                    'thursday': 'Csütörtök', 'friday': 'Péntek', 'saturday': 'Szombat', 'sunday': 'Vasárnap'}

    day_index = day_names_en.index(day)
    day_date = program_start + timedelta(days=day_index)
    day_program_index = day_index
    
    running_pace_min = 5
    running_pace_sec = 30
    running_avg_km = 5.0
    
    if profile.current_running_distance_km:
        running_avg_km = profile.current_running_distance_km
    if profile.current_running_pace_min:
        running_pace_min = int(profile.current_running_pace_min)
        running_pace_sec = int((profile.current_running_pace_min % 1) * 60)
    
    if prefs:
        if not profile.current_running_distance_km:
            running_avg_km = prefs.running_avg_distance_km or 5.0
        if not profile.current_running_pace_min:
            running_pace_min = prefs.running_pace_min or 5
            running_pace_sec = prefs.running_pace_sec or 30
    
    training_days = []
    if profile.training_days:
        try:
            training_days = json.loads(profile.training_days)
        except:
            training_days = []
    
    is_training_day = day in training_days
    
    base_km = running_avg_km
    
    if profile.goal == 'fogyás':
        base_km *= 1.1 
    elif profile.goal in ['hízás', 'izomépítés']:
        base_km *= 0.8  
    
    if is_training_day:
        if day in ['saturday', 'sunday']:
            day_km = round(base_km * 1.2, 1)
            run_type = 'long'
            run_name = 'Hosszú futás'
        else:
            day_km = round(base_km, 1)
            run_type = 'normal'
            run_name = 'Alap futás'
    else:
        day_km = round(base_km * 0.5, 1)
        run_type = 'recovery'
        run_name = 'Regeneráló futás'
    
    pace_total_sec = (running_pace_min * 60) + running_pace_sec
    day_time_min = int((day_km * pace_total_sec) / 60)
    
    weight = profile.current_weight_kg
    met = 10.0 
    day_calories_burned = int(met * weight * (day_time_min / 60))
    
    work_days = []
    if profile.work_days_per_week:
        try:
            work_days = json.loads(profile.work_days_per_week)
        except:
            work_days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday']
    else:
        work_days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday']
    
    is_work_day = day in work_days
    work_start = profile.work_start_time or '08:00'
    work_end = profile.work_end_time or '17:00'
    workout_pref = profile.workout_time_preference or 'flexible'
    
    daily_log = DailyLog.query.filter_by(
        user_id=current_user.id,
        date=day_date
    ).first()
    
    day_weight = None
    sleep_hours = 7
    if daily_log:
        day_weight = daily_log.weight_kg
        sleep_hours = daily_log.sleep_hours or 7
    
    if not day_weight:
        day_weight = profile.current_weight_kg or profile.starting_weight_kg

    daily_steps = daily_log.steps_completed if daily_log else (profile.daily_steps_goal or 5000)
    is_training_day = True
    day_nutrition = calculate_day_nutrition(profile, is_work_day, sleep_hours, day_weight, daily_steps, is_training_day)
    
    if is_training_day:
        day_nutrition['calories'] += int(day_calories_burned * 0.5) #50%
    
    target_cals = day_nutrition['calories']
    target_protein = day_nutrition['protein']
    target_carbs = day_nutrition['carbs']
    target_fat = day_nutrition['fat']
    target_water = day_nutrition['water']
    
    if is_training_day:
        target_water += 500
    
    wake_time = profile.wake_time or '07:00'
    bed_time = profile.bed_time or '22:00'
    
    daily_meals = 4
    if daily_log and daily_log.meals_count:
        daily_meals = daily_log.meals_count
    
    meals = {}
    if daily_meals <= 3:
        meals = {
            'breakfast': {'name': 'Reggeli', 'icon': '🌅', 'percent': 0.30, 'time': wake_time},
            'lunch': {'name': 'Ebéd', 'icon': '☀️', 'percent': 0.40, 'time': '12:30'},
            'dinner': {'name': 'Vacsora', 'icon': '🌙', 'percent': 0.30, 'time': '19:00'}
        }
    else:
        meals = {
            'breakfast': {'name': 'Reggeli', 'icon': '🌅', 'percent': 0.25, 'time': wake_time},
            'lunch': {'name': 'Ebéd', 'icon': '☀️', 'percent': 0.35, 'time': '12:30'},
            'snack': {'name': 'Uzsonna', 'icon': '🥜', 'percent': 0.15, 'time': '16:00'},
            'dinner': {'name': 'Vacsora', 'icon': '🌙', 'percent': 0.25, 'time': '19:00'}
        }
    
    for meal_key, meal in meals.items():
        meal['calories'] = int(target_cals * meal['percent'])
        meal['recipes'] = get_recipe_recommendations(meal_key, meal['calories'], target_protein=target_protein, limit=3)
    
    water_schedule = [
        {'time': 'Ébredés után', 'amount': 250, 'tip': 'Indítsd a napot egy pohár vízzel!'},
        {'time': 'Futás előtt (30p)', 'amount': 300, 'tip': 'Fontos a hidratálás futás előtt!'},
        {'time': 'Futás közben', 'amount': 200, 'tip': 'Kortyolj rendszeresen'},
        {'time': 'Futás után', 'amount': 400, 'tip': '🏃 Pótold a veszteséget!'},
        {'time': 'Délután', 'amount': 500, 'tip': 'Folyamatos hidratálás'},
        {'time': 'Este', 'amount': 250, 'tip': 'Ne túl sokat lefekvés előtt'}
    ]
    
    run_schedule = []
    if is_training_day:
        if workout_pref == 'before_work' and is_work_day:
            run_time = f'{int(work_start.split(":")[0]) - 1}:00'
            run_schedule = [
                {'phase': 'Bemelegítés', 'duration': 5, 'intensity': 'könnyű', 'tip': 'Laza tempó, izomátmozgatás'},
                {'phase': 'Fő futás', 'duration': day_time_min - 10, 'intensity': 'közepes', 'tip': f'🏃 {day_km} km @ {running_pace_min}:{running_pace_sec:02d}/km'},
                {'phase': 'Lehűtés', 'duration': 5, 'intensity': 'könnyű', 'tip': 'Lassú kocogás, séta'}
            ]
        elif workout_pref == 'after_work' and is_work_day:
            run_time = work_end
            run_schedule = [
                {'phase': 'Bemelegítés', 'duration': 5, 'intensity': 'könnyű', 'tip': 'Laza tempó, izomátmozgatás'},
                {'phase': 'Fő futás', 'duration': day_time_min - 10, 'intensity': 'közepes', 'tip': f'🏃 {day_km} km @ {running_pace_min}:{running_pace_sec:02d}/km'},
                {'phase': 'Lehűtés', 'duration': 5, 'intensity': 'könnyű', 'tip': 'Lassú kocogás, séta'}
            ]
        else:
            run_time = 'Szabadon választott'
            run_schedule = [
                {'phase': 'Bemelegítés', 'duration': 5, 'intensity': 'könnyű', 'tip': 'Laza tempó, izomátmozgatás'},
                {'phase': 'Fő futás', 'duration': day_time_min - 10, 'intensity': 'közepes', 'tip': f'🏃 {day_km} km @ {running_pace_min}:{running_pace_sec:02d}/km'},
                {'phase': 'Lehűtés', 'duration': 5, 'intensity': 'könnyű', 'tip': 'Lassú kocogás, séta'}
            ]
    else:
        run_time = 'Pihenőnap'
        run_schedule = [
            {'phase': 'Könnyű mozgás', 'duration': 15, 'intensity': 'nagyon könnyű', 'tip': '😴 Aktív pihenés - séta vagy nyújtás'}
        ]
    
    day_info = {
        'name': day_names_hu[day],
        'type': 'training' if is_training_day else 'rest',
        'run_type': run_type,
        'run_name': run_name
    }
    
    days_data = []
    for i, d_name in enumerate(day_names_en):
        d_date = program_start + timedelta(days=i)
        d_log = DailyLog.query.filter_by(user_id=current_user.id, date=d_date).first()
        days_data.append({
            'short': d_name,
            'name': day_names_hu[d_name],
            'date': d_date,
            'is_training': d_name in training_days,
            'completed': d_log.completed if d_log else False,
            'is_today': d_date == today,
            'is_current': d_name == day
        })
    
    checkin_completed = daily_log and daily_log.completed
    needs_daily_input = not daily_log or daily_log.weight_kg is None or daily_log.sleep_hours is None
    
    program_day_index = (day_date - program_start).days
    
    next_day = None
    next_day_name = None
    is_last_day = program_day_index >= 6
    
    if not is_last_day:
        next_day_date = day_date + timedelta(days=1)
        next_day_weekday = next_day_date.weekday()
        next_day = day_names_en[next_day_weekday]
        next_day_name = day_names_hu[next_day]
    
    return render_template('workouts/running_day.html',
                         profile=profile,
                         prefs=prefs,
                         day=day,
                         day_info=day_info,
                         day_km=day_km,
                         day_time_min=day_time_min,
                         day_calories_burned=day_calories_burned,
                         running_pace_min=running_pace_min,
                         running_pace_sec=running_pace_sec,
                         run_schedule=run_schedule,
                         run_time=run_time,
                         meals=meals,
                         target_cals=target_cals,
                         target_protein=target_protein,
                         target_carbs=target_carbs,
                         target_fat=target_fat,
                         day_nutrition=day_nutrition,
                         water_schedule=water_schedule,
                         target_water=target_water,
                         days_data=days_data,
                         is_work_day=is_work_day,
                         is_training_day=is_training_day,
                         checkin_completed=checkin_completed,
                         daily_log=daily_log,
                         day_date=day_date,
                         needs_daily_input=needs_daily_input,
                         daily_meals=daily_meals,
                         next_day=next_day,
                         next_day_name=next_day_name,
                         is_last_day=is_last_day,
                         day_weight=day_weight)


@bp.route('/start/<int:day_id>')
@login_required
def start_workout(day_id):
    workout_day = WorkoutDay.query.get_or_404(day_id)
    exercises = WorkoutDayExercise.query.filter_by(
        workout_day_id=day_id
    ).order_by(WorkoutDayExercise.order).all()
    
    previous_logs = {}
    for wde in exercises:
        last_log = UserExerciseLog.query.join(UserWorkoutLog).filter(
            UserWorkoutLog.user_id == current_user.id,
            UserExerciseLog.exercise_id == wde.exercise_id
        ).order_by(UserExerciseLog.id.desc()).first()
        
        if last_log:
            previous_logs[wde.exercise_id] = {
                'weight': last_log.weight_kg,
                'reps': last_log.reps_completed
            }
    
    return render_template('workouts/start.html',
                         workout_day=workout_day,
                         exercises=exercises,
                         previous_logs=previous_logs)


@bp.route('/complete/<int:day_id>', methods=['POST'])
@login_required
def complete_workout(day_id):
    workout_day = WorkoutDay.query.get_or_404(day_id)
    
    workout_log = UserWorkoutLog(
        user_id=current_user.id,
        workout_day_id=day_id,
        completed=True,
        duration_minutes=int(request.form.get('duration', 0)),
        notes=request.form.get('notes', '')
    )
    db.session.add(workout_log)
    db.session.flush()
    
    exercises = WorkoutDayExercise.query.filter_by(workout_day_id=day_id).all()
    
    for wde in exercises:
        for set_num in range(1, wde.sets + 1):
            reps = request.form.get(f'reps_{wde.id}_{set_num}', 0)
            weight = request.form.get(f'weight_{wde.id}_{set_num}', 0)
            
            if reps or weight:
                exercise_log = UserExerciseLog(
                    user_workout_log_id=workout_log.id,
                    exercise_id=wde.exercise_id,
                    set_number=set_num,
                    reps_completed=int(reps) if reps else 0,
                    weight_kg=float(weight) if weight else 0
                )
                db.session.add(exercise_log)
    
    db.session.commit()
    
    flash('🎉 Szép munka! Edzés sikeresen befejezve!', 'success')
    return redirect(url_for('workouts.index'))


@bp.route('/exercise/<int:exercise_id>')
@login_required
def exercise_detail(exercise_id):
    exercise = Exercise.query.get_or_404(exercise_id)
    
    logs = UserExerciseLog.query.join(UserWorkoutLog).filter(
        UserWorkoutLog.user_id == current_user.id,
        UserExerciseLog.exercise_id == exercise_id
    ).order_by(UserExerciseLog.id.desc()).limit(10).all()
    
    return render_template('workouts/exercise.html',
                         exercise=exercise,
                         logs=logs)


@bp.route('/history')
@login_required
def history():
    from app.models.user import WeeklyResult
    
    all_results = WeeklyResult.query.filter_by(
        user_id=current_user.id
    ).order_by(WeeklyResult.week_start.desc()).all()
    

    weekly_results = [r for r in all_results if r.program_type == 'weekly' or r.program_type is None]
    monthly_results = [r for r in all_results if r.program_type == 'monthly']
    
    monthly_groups = []
    current_group = []
    for r in monthly_results:
        current_group.append(r)
        if r.week_number == 4 or (r.week_number == 1 and len(current_group) > 1):
            if len(current_group) > 1:
                monthly_groups.append(current_group[:-1])
                current_group = [r]
    if current_group:
        monthly_groups.append(current_group)

    total_weeks = len(all_results)
    total_all_steps = sum(r.total_steps or 0 for r in all_results)
    total_all_km = sum(r.total_km or 0 for r in all_results)
    total_weight_lost = 0
    if all_results:
        first_result = all_results[-1] if all_results else None
        last_result = all_results[0] if all_results else None
        if first_result and last_result and first_result.start_weight and last_result.end_weight:
            total_weight_lost = round(first_result.start_weight - last_result.end_weight, 1)
    
    return render_template('workouts/history.html', 
                         weekly_results=weekly_results,
                         monthly_results=monthly_results,
                         monthly_groups=monthly_groups,
                         all_results=all_results,
                         total_weeks=total_weeks,
                         total_all_steps=total_all_steps,
                         total_all_km=total_all_km,
                         total_weight_lost=total_weight_lost)
