from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from config import Config
import os
import json

db = SQLAlchemy()
login_manager = LoginManager()

def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)
    
    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'
    login_manager.login_message = 'Jelentkezz be!'
    
    @app.template_filter('from_json')
    def from_json_filter(value):
        if not value:
            return []
        try:
            return json.loads(value)
        except:
            return []
    
    with app.app_context():
        from app.models import user
        
        from app.routes import auth
        from app.routes import recipes
        from app.routes import workouts
        
        app.register_blueprint(auth.bp)
        app.register_blueprint(recipes.bp)
        app.register_blueprint(workouts.bp)
        
        db.create_all()
        
        _auto_seed_database(app)
    
    return app


def _auto_seed_database(app):
    from app.models.user import Recipe
    if Recipe.query.filter_by(is_seed=True).count() == 0:
        _load_recipes_seed(app)



def _load_recipes_seed(app):
    from app.models.user import Recipe
    
    seed_file = os.path.join(app.root_path, '..', 'recipes_seed.json')
    if not os.path.exists(seed_file):
        return
    
    try:
        with open(seed_file, 'r', encoding='utf-8') as f:
            recipes_data = json.load(f)
        
        count = 0
        for recipe_data in recipes_data:
            recipe = Recipe(
                name=recipe_data['name'],
                category=recipe_data.get('category', 'lunch'),
                calories=recipe_data.get('calories', 0),
                protein_g=recipe_data.get('protein_g', 0),
                carbs_g=recipe_data.get('carbs_g', 0),
                fat_g=recipe_data.get('fat_g', 0),
                servings=recipe_data.get('servings', 1),
                ready_in_minutes=recipe_data.get('ready_in_minutes', 30),
                image_url=recipe_data.get('image_url'),
                source_url=recipe_data.get('source_url'),
                ingredients=json.dumps(recipe_data.get('ingredients', []), ensure_ascii=False),
                instructions=recipe_data.get('instructions', ''),
                is_seed=True
            )
            db.session.add(recipe)
            count += 1
        
        db.session.commit()
        print(f"✅ {count} recept betöltve")
    except Exception as e:
        print(f"❌ Recept betöltési hiba: {e}")
        db.session.rollback()
