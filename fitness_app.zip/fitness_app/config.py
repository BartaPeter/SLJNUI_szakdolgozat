import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev-secret-key-2024'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///fitness_app.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    SPOONACULAR_API_KEY = '4d2060da9f1640e897f16538d4883462'
    SPOONACULAR_BASE_URL = 'https://api.spoonacular.com' #API hozzaferes
