import json
from app import create_app, db
from app.models.user import Recipe

def import_recipes():
    
    app = create_app()
    
    with app.app_context():
        existing_count = Recipe.query.filter_by(is_manual=True, is_seed=True).count()
        
        if existing_count > 0:
            print(f"⚠️  Már van {existing_count} seed recept az adatbázisban!")
            response = input("Törölni szeretnéd őket és újra importálni? (y/n): ")
            if response.lower() != 'y':
                print(" Import megszakítva")
                return

            Recipe.query.filter_by(is_seed=True).delete()
            db.session.commit()
            print(" Régi seed receptek törölve")
        
        with open('recipes_seed.json', 'r', encoding='utf-8') as f:
            recipes_data = json.load(f)
        
        print(f"\n📦 {len(recipes_data)} recept importálása...")
        
        imported = 0
        for recipe_data in recipes_data:
            recipe = Recipe(
                name=recipe_data['name'],
                category=recipe_data['category'],
                calories=recipe_data['calories'],
                protein_g=recipe_data['protein_g'],
                carbs_g=recipe_data['carbs_g'],
                fat_g=recipe_data['fat_g'],
                servings=recipe_data['servings'],
                ready_in_minutes=recipe_data['ready_in_minutes'],
                image_url=recipe_data['image_url'],
                source_url=recipe_data['source_url'],
                ingredients=recipe_data['ingredients'],
                instructions=recipe_data['instructions'],
                user_id=None,
                is_manual=True, 
                is_seed=True, 
                is_favorite=False
            )
            db.session.add(recipe)
            imported += 1
        
        db.session.commit()
        
        print(f"\n✅ Sikeres import: {imported} recept!")
        print(f"\n📊 Kategóriák:")
        
        for category in ['breakfast', 'lunch', 'dinner', 'snack']:
            count = Recipe.query.filter_by(category=category, is_seed=True).count()
            category_names = {
                'breakfast': 'Reggeli',
                'lunch': 'Ebéd',
                'dinner': 'Vacsora',
                'snack': 'Snack'
            }
            print(f"  - {category_names[category]}: {count} db")

if __name__ == '__main__':
    import_recipes()
